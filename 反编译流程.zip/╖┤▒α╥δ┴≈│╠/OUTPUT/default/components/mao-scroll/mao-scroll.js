var t = require("../../common/vendor.js"),
  i = {
    name: "maoScroll",
    data: function() {
      return {
        showdata: [],
        marginTop: 0,
        showLine: 0,
        nameList: this.nameCommonList
      }
    },
    props: {
      data: {
        type: Array,
        default: []
      },
      showNum: {
        type: Number,
        default: 3
      },
      lineHeight: {
        type: Number,
        default: 56
      },
      animationScroll: {
        type: Number,
        default: 500
      },
      animation: {
        type: Number,
        default: 2e3
      }
    },
    methods: {
      filterName: function(t, i) {
        return t > 40 && (t = 0), i[t].slice(0, 3)
      },
      init: function() {
        this.showLine = this.showNum < this.data.length ? this.showNum : this.data.length;
        for (var t = 0; t < this.data.length; t++) this.showdata.push(this.data[t]);
        for (var i = 0; i < this.showLine; i++) this.showdata.push(this.data[i]);
        setInterval(this.animationFunc, this.animation)
      },
      animationFunc: function() {
        this.marginTop >= this.data.length * this.lineHeight ? this.marginTop = 0 : this.marginTop += this.lineHeight
      }
    },
    watch: {
      data: function(t, i) {
        this.init()
      }
    },
    created: function() {
      var t = this;
      this.$nextTick((function() {
        var i;
        t.userList = (null == (i = t.userCommonList) ? void 0 : i.slice(0, 40)) || [], t.init()
      }))
    }
  },
  a = t._export_sfc(i, [
    ["render", function(i, a, n, e, s, h) {
      return {
        a: t.f(s.showdata, (function(i, a, n) {
          return {
            a: i,
            b: t.t(h.filterName(a, s.nameList)),
            c: a
          }
        })),
        b: t.s("height:" + n.lineHeight + "rpx;"),
        c: t.s("transform: translateY(-" + s.marginTop + "rpx);"),
        d: t.s("height:" + n.lineHeight * s.showLine + "rpx;")
      }
    }],
    ["__scopeId", "data-v-6f64db7a"]
  ]);
wx.createComponent(a);