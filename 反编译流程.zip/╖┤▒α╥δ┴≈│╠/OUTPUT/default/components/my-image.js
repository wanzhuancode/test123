var i = require("../common/vendor.js"),
  e = {
    name: "my-image",
    props: {
      img: {
        type: Object,
        default: {}
      },
      col: {
        default: 3
      }
    },
    data: function() {
      return {
        load: !1,
        imgType: ""
      }
    },
    methods: {
      selectImg: function(i) {
        this.$emit("selectImg")
      },
      loadImage: function(i) {
        var e = i.target;
        e.height >= e.width ? this.imgType = "img-2" : this.imgType = "img-3", 2 != this.img.class && 3 != this.img.class && 4 != this.img.class || (this.imgType = "img-1"), this.load = !0
      }
    }
  },
  m = i._export_sfc(e, [
    ["render", function(e, m, t, g, o, a) {
      return i.e({
        a: t.img.img
      }, t.img.img ? i.e({
        b: t.img.is_top > 0 && o.load
      }, (t.img.is_top > 0 && o.load, {}), {
        c: i.n("".concat(o.imgType)),
        d: o.load,
        e: e.$link(t.img.img),
        f: i.o((function() {
          return a.loadImage && a.loadImage.apply(a, arguments)
        })),
        g: t.img.img.includes(".mp4") && o.load
      }, (t.img.img.includes(".mp4") && o.load, {}), {
        h: i.n("img-box-".concat(t.col)),
        i: i.o((function() {
          return a.selectImg && a.selectImg.apply(a, arguments)
        }))
      }) : {})
    }]
  ]);
wx.createComponent(m);