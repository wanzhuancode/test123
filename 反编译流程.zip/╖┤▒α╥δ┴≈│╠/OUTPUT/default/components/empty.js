var t = require("../common/vendor.js"),
  e = {
    name: "empty",
    props: {
      emptyStyle: {
        type: String,
        default: ""
      },
      text: {
        type: String,
        default: "暂无内容~"
      },
      icon: {
        default: "http://min-cdn.xliii.cn/miniapp/juejinbizhi/ts_new/author/empty.png"
      }
    },
    data: function() {
      return {}
    }
  },
  n = t._export_sfc(e, [
    ["render", function(e, n, i, r, p, a) {
      return {
        a: i.icon,
        b: t.t(i.text),
        c: t.s(i.emptyStyle)
      }
    }],
    ["__scopeId", "data-v-c7ea3283"]
  ]);
wx.createComponent(n);