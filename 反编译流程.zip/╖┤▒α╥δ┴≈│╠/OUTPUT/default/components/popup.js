var o = require("../common/vendor.js"),
  t = {
    name: "popup",
    props: {
      show: {
        type: Boolean,
        default: !1
      }
    },
    watch: {
      show: function(o) {
        var t = this;
        o ? (this.showPop = o, setTimeout((function() {
          t.showCont = !0
        }), 200)) : (this.showCont = !1, setTimeout((function() {
          t.showPop = o
        }), 200))
      }
    },
    data: function() {
      return {
        showCont: !1,
        showPop: !1
      }
    },
    created: function() {
      var o = this;
      console.log(this.show), this.showPop = this.show, this.show && setTimeout((function() {
        o.showCont = !0
      }), 200)
    },
    methods: {
      closePop: function() {
        this.$emit("close")
      }
    }
  },
  s = o._export_sfc(t, [
    ["render", function(t, s, n, e, h, i) {
      return o.e({
        a: h.showPop
      }, h.showPop ? {
        b: o.o((function() {})),
        c: h.showCont ? 1 : "",
        d: o.o((function() {
          return i.closePop && i.closePop.apply(i, arguments)
        }))
      } : {})
    }]
  ]);
wx.createComponent(s);