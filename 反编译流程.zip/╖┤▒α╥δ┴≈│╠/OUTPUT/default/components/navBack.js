var e = require("../common/vendor.js"),
  n = {
    props: {
      back: {
        type: Boolean,
        default: !1
      }
    },
    name: "navBack",
    data: function() {
      return {
        navTop: e.index.getSystemInfoSync().statusBarHeight + "px"
      }
    },
    methods: {
      goBack: function() {
        if (console.log(this.back), this.back) return this.$emit("goBackPage");
        getCurrentPages().length > 1 ? e.index.navigateBack() : e.index.reLaunch({
          url: "/pages/index/index"
        })
      }
    }
  },
  t = e._export_sfc(n, [
    ["render", function(n, t, a, o, r, c) {
      return {
        a: e.o((function() {
          return c.goBack && c.goBack.apply(c, arguments)
        })),
        b: r.navTop
      }
    }]
  ]);
wx.createComponent(t);