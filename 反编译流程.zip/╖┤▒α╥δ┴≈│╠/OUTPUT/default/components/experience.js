var o = require("../common/vendor.js"),
  t = {
    name: "experience",
    props: {
      show: {
        type: Boolean,
        default: !1
      }
    },
    watch: {
      show: function(o) {
        var t = this;
        o ? (this.showPop = o, setTimeout((function() {
          t.showCont = !0
        }), 200)) : (this.showCont = !1, setTimeout((function() {
          t.showPop = o
        }), 200))
      }
    },
    data: function() {
      return {
        showPop: !1,
        showCont: !1
      }
    },
    created: function() {
      var o = this;
      this.showPop = this.show, this.show && setTimeout((function() {
        o.showCont = !0
      }), 200)
    },
    methods: {
      closePop: function() {
        this.$emit("close", !1)
      },
      openVip: function() {
        this.$emit("clickBtn", !1)
      }
    }
  },
  n = o._export_sfc(t, [
    ["render", function(t, n, e, s, i, c) {
      return o.e({
        a: i.showPop
      }, i.showPop ? {
        b: o.o((function() {
          return c.closePop && c.closePop.apply(c, arguments)
        })),
        c: o.o((function(o) {
          return c.openVip(!1)
        })),
        d: o.o((function() {})),
        e: i.showCont ? 1 : "",
        f: o.o((function() {
          return c.closePop && c.closePop.apply(c, arguments)
        }))
      } : {})
    }],
    ["__scopeId", "data-v-d2c1888a"]
  ]);
wx.createComponent(n);