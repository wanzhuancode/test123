var s = require("../common/vendor.js"),
  t = require("../utils/js/common.js"),
  a = require("../utils/js/pay.js"),
  o = !1,
  e = getApp(),
  i = {
    name: "down-view",
    components: {
      popup: function() {
        return "./popup.js"
      }
    },
    props: {
      resId: {
        type: [String, Number],
        default: ""
      },
      albId: {
        type: [String, Number],
        default: 0
      },
      show: {
        type: Boolean,
        default: !1
      },
      img: {
        type: Object,
        default: function() {}
      },
      downType: {
        default: "img"
      }
    },
    data: function() {
      return {
        pay_mod: null,
        top_bg: "http://min-cdn.xliii.cn/miniapp/juejinbizhi/ts_new/1693536412rMgZ4.png",
        showOverrun: !1,
        showSuccess: !1,
        spare_cash: null,
        res_type: 1,
        play_src: 1
      }
    },
    watch: {
      show: function(s) {
        if (!s) return !1;
        this.cashDesk()
      }
    },
    mounted: function() {
      t.initRewardVideo(!0)
    },
    methods: {
      cashDesk: function() {
        var t = this,
          a = s.index.getSystemInfoSync(),
          o = a.hostName,
          e = a.hostVersion,
          i = a.platform;
        this.$api.cashDesk({
          data: {
            res_id: this.resId,
            res_type: this.res_type,
            sopenid: getApp().globalData.code,
            app_name: o,
            app_ver: e,
            platform: i
          }
        }).then((function(s) {
          console.log(s), t.pay_mod = s, t.spare_cash = s.ad_cash.spare_cash
        }))
      },
      closePopup: function() {
        this.$emit("update:show", !1)
      },
      bindTypeBtn: function(s) {
        if (o) return !1;
        switch (o = !0, s) {
          case 1:
            this.bindAdBtn(s);
            break;
          case 3:
            this.bindPayBtn(s);
            break;
          case 2:
            this.bindVipBtn(s)
        }
        setTimeout((function() {
          o = !1
        }), 1500)
      },
      bindAdBtn: function(s) {
        var t = this.pay_mod.ad_cash;
        if (1 == t.status) this.playAdVideo(s);
        else if (2 == t.status) {
          1 == this.spare_cash.status ? (this.closePopup(), this.showOverrun = !0, o = !1) : (this.showModal(t.tip_desc), o = !1)
        } else 3 == t.status && this.downImage(s)
      },
      bindPayBtn: function(s) {
        var t = this,
          i = this.pay_mod.pay_gid_cash;
        1 == i.status ? a.payMixin({
          sopenid: e.globalData.code,
          res_type: 1,
          res_id: this.resId,
          good_id: i.good_data.good_id
        }, (function(a, e) {
          1 == a ? t.downImage(s) : (t.payFail(s, e), o = !1)
        })) : 3 == i.status && this.downImage(s)
      },
      payFail: function(t, a) {
        s.index.showModal({
          content: "订单查询失败",
          confirmText: "重新查询",
          success: function(a) {
            var o = this;
            a.confirm && (s.index.showLoading({
              title: "查询中..."
            }), this.queryOrder((function(a, e) {
              1 == a && o.downImage(t), s.index.hideLoading()
            })))
          }
        })
      },
      bindVipBtn: function(t) {
        var a = this.pay_mod.pay_vip_cash;
        1 == a.status ? (this.closePopup(), o = !1, s.index.navigateTo({
          url: "/pages/membership/membership?gid=" + this.img.res_id
        })) : 2 == a.status ? (console.log(a), this.showModal(a.tip_desc), o = !1) : 3 == a.status && this.downImage(t)
      },
      playAdVideo: function(a) {
        var e = this;
        s.index.showLoading({
          title: "广告加载中..."
        }), console.log("start ad"), t.playVideo((function(i) {
          s.index.hideLoading(), t.adReport({
            alb_id: e.albId || 0,
            res_id: e.img.res_id || 0,
            acc_id: e.img.acc_id || 0,
            res_type: e.res_type
          }, i), console.log("ad status", i), 2 == i ? (s.index.showToast({
            title: "看完广告才可以查看结果！",
            icon: "none"
          }), o = !1) : 1003 == i || 1004 == i ? (s.index.showToast({
            title: "广告异常,请在24小时后重试!",
            icon: "none"
          }), o = !1) : e.downImage(a)
        }))
      },
      downImage: function(a) {
        var e = this;
        s.index.showLoading({
          title: "下载中..."
        });
        var i = this.img.img;
        console.log(i), "video_url" == this.downType && (i = this.img.video_url), o = !1, t.downloadFile(i).then((function(t) {
          o = !1, s.index.hideLoading(), e.showSuccess = !0, e.closePopup(), e.playReport(a)
        })).catch((function(t) {
          o = !1, s.index.hideLoading(), s.index.showToast({
            title: "下载失败！",
            icon: "none"
          }), e.closePopup()
        }))
      },
      playReport: function(s) {
        this.$api.playReport({
          data: {
            sopenid: getApp().globalData.code,
            res_type: this.res_type,
            res_id: this.img.res_id || 0,
            play_src: s
          }
        })
      },
      showModal: function(t) {
        s.index.showModal({
          content: t,
          showCancel: !1
        })
      },
      jumpApp: function() {
        var s = this.pay_mod.ad_cash.spare_cash.jump_cash;
        if (1 != s.status) return this.showModal("今日下载次数用完\n明天再来噢~");
        console.log(s), console.log(s.appid);
        var t = e.globalData,
          a = t.acc_id,
          o = t.code,
          i = 2 == this.img.class || 3 == this.img.class ? "avatar" : "preview",
          n = "pages/author/author?acc_id=".concat(a || 1, "&code=").concat(o, "&res_id=").concat(this.img.res_id, "&page_path=").concat(i);
        console.log(n), console.log(s.appid), tt.navigateToMiniProgram({
          appId: s.appid,
          path: n,
          success: function(s) {
            console.log(s)
          },
          fail: function(s) {
            console.log(s)
          }
        })
      },
      openVip: function() {
        this.closePopup(), this.showOverrun = !1, s.index.navigateTo({
          url: "/pages/membership/membership?gid=" + this.img.res_id
        })
      }
    }
  };
Array || s.resolveComponent("popup")();
var n = s._export_sfc(i, [
  ["render", function(t, a, o, e, i, n) {
    return s.e({
      a: i.pay_mod
    }, i.pay_mod ? s.e({
      b: i.top_bg,
      c: 0 != i.pay_mod.ad_cash.status
    }, 0 != i.pay_mod.ad_cash.status ? {
      d: s.t(i.pay_mod.ad_cash.title),
      e: s.t(i.pay_mod.ad_cash.desc),
      f: s.t(i.pay_mod.ad_cash.btn),
      g: s.o((function(s) {
        return n.bindTypeBtn(i.pay_mod.ad_cash.play_src)
      }))
    } : {}, {
      h: 0 != i.pay_mod.pay_gid_cash.status
    }, 0 != i.pay_mod.pay_gid_cash.status ? {
      i: s.t(i.pay_mod.pay_gid_cash.title),
      j: s.t(i.pay_mod.pay_gid_cash.desc),
      k: s.t(i.pay_mod.pay_gid_cash.btn),
      l: s.o((function(s) {
        return n.bindTypeBtn(i.pay_mod.pay_gid_cash.play_src)
      }))
    } : {}, {
      m: 0 != i.pay_mod.pay_vip_cash.status
    }, 0 != i.pay_mod.pay_vip_cash.status ? {
      n: s.t(i.pay_mod.pay_vip_cash.title),
      o: s.t(i.pay_mod.pay_vip_cash.desc),
      p: s.t(i.pay_mod.pay_vip_cash.btn),
      q: s.o((function(s) {
        return n.bindTypeBtn(i.pay_mod.pay_vip_cash.play_src)
      }))
    } : {}, {
      r: s.o((function() {}))
    }) : {}, {
      s: s.o(n.closePopup),
      t: s.p({
        show: o.show
      }),
      v: i.spare_cash
    }, i.spare_cash ? s.e({
      w: 0 != i.spare_cash.vip_cash.status
    }, 0 != i.spare_cash.vip_cash.status ? {
      x: s.o((function() {
        return n.openVip && n.openVip.apply(n, arguments)
      }))
    } : {}, {
      y: 0 != i.spare_cash.jump_cash.status
    }, 0 != i.spare_cash.jump_cash.status ? {
      z: s.o((function() {
        return n.jumpApp && n.jumpApp.apply(n, arguments)
      }))
    } : {}, {
      A: s.o((function(s) {
        return i.showOverrun = !1
      })),
      B: s.o((function(s) {
        return i.showOverrun = !1
      })),
      C: s.p({
        show: i.showOverrun
      })
    }) : {}, {
      D: s.o((function(s) {
        return i.showSuccess = !1
      })),
      E: s.o((function(s) {
        return i.showSuccess = !1
      })),
      F: s.p({
        show: i.showSuccess
      })
    })
  }],
  ["__scopeId", "data-v-9572b34a"]
]);
wx.createComponent(n);