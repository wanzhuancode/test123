var a = require("../common/vendor.js"),
  n = {
    name: "complain",
    data: function() {
      return {
        globalData: getApp().globalData
      }
    },
    created: function() {},
    methods: {
      jumpComplain: function() {
        a.index.navigateTo({
          url: "/pages/complain/complain"
        })
      }
    }
  },
  o = a._export_sfc(n, [
    ["render", function(n, o, e, t, c, p) {
      return {
        a: 0 == c.globalData.check,
        b: a.o((function() {
          return p.jumpComplain && p.jumpComplain.apply(p, arguments)
        }))
      }
    }],
    ["__scopeId", "data-v-58c7d51c"]
  ]);
wx.createComponent(o);