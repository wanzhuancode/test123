var e = require("../common/vendor.js"),
  o = {
    props: {
      showAdvert: {
        type: Boolean,
        deafult: !1
      }
    },
    name: "advert",
    data: function() {
      return {}
    },
    watch: {
      showAdvert: function(e) {
        e ? this.$refs.popup.open() : this.$refs.popup.close()
      }
    },
    methods: {
      close: function() {
        this.$emit("close", !1)
      }
    }
  };
Array || e.resolveComponent("uni-popup")(), Math;
var r = e._export_sfc(o, [
  ["render", function(o, r, t, n, p, s) {
    return {
      a: e.o((function() {
        return s.close && s.close.apply(s, arguments)
      })),
      b: e.sr("popup", "4ef4f042-0"),
      c: e.o(s.close),
      d: e.p({
        type: "center",
        round: "40rpx"
      })
    }
  }]
]);
wx.createComponent(r);