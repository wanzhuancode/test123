require("../../@babel/runtime/helpers/Arrayincludes");
var n = require("../../@babel/runtime/helpers/objectSpread2"),
  e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  o = require("../../common/vendor.js"),
  i = require("../../service/api.js"),
  a = function(n) {
    o.index.canIUse("getUserInfo")
  },
  r = function(n, e, t) {
    o.index.getSetting({
      success: function(o) {
        o.authSetting[n] || void 0 === o.authSetting[n] ? t && t() : !1 === o.authSetting[n] && u(n, e, t)
      }
    }), o.index.hideLoading()
  },
  c = function(n, e) {
    var t = e.split("."),
      i = function(n) {
        n = n || 16;
        for (var e = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678", t = e.length, o = "", i = 0; i < n; i++) o += e.charAt(Math.floor(Math.random() * t));
        return o
      }() + "." + t[t.length - 1];
    return o.index.uploadFile({
      url: "https://up-z2.qiniup.com",
      filePath: e,
      name: "file",
      header: {
        "Content-Type": "multipart/form-data"
      },
      formData: {
        token: n.token,
        key: n.path + i
      }
    })
  },
  u = function(n, e, t) {
    o.index.showModal({
      title: "提示",
      content: e,
      success: function(e) {
        e.confirm ? o.index.openSetting({
          success: function(e) {
            e.authSetting[n] && t && t()
          },
          fail: function(n) {
            console.log(!1)
          }
        }) : console.log(!1)
      }
    })
  },
  d = {
    domain: "http://min-cdn.xliii.cn/",
    down_domain: "https://min-cdn.xliii.cn/",
    img_thumb: "?imageView2/2/w/240/interlace/1",
    video_thumb: "?vframe/png/offset/1/w/240"
  },
  s = function n(e, t, i) {
    return new Promise((function(a, r) {
      o.index.downloadFile({
        url: i.startsWith("http") ? i : d.down_domain + i,
        success: function(c) {
          console.log(c), o.index.saveImageToPhotosAlbum({
            filePath: c.tempFilePath,
            success: function() {
              a()
            },
            fail: function(o) {
              console.log("saveImageToPhotosAlbum err", o), console.log(o.errNo), 10200 == o.errNo ? u(e, t, (function() {
                n(e, t, i)
              })) : r(!1)
            }
          })
        },
        fail: function(n) {
          console.log("downloadImage func fail err", n), r(n)
        }
      })
    }))
  },
  l = function n(e, t, i) {
    return new Promise((function(a, r) {
      o.index.downloadFile({
        url: d.down_domain + i,
        success: function(c) {
          console.log(c), o.index.saveVideoToPhotosAlbum({
            filePath: c.tempFilePath,
            success: function() {
              a()
            },
            fail: function(o) {
              10200 == o.errNo ? u(e, t, (function() {
                n(e, t, i)
              })) : r(!1)
            }
          })
        },
        fail: function(n) {
          r(n)
        }
      })
    }))
  },
  f = function() {
    var n = new Date;
    return n.getFullYear().toString() + n.getMonth().toString() + n.getDate().toString()
  },
  g = function(n, e) {
    var t = getApp().globalData.appid;
    if (e) {
      var i = o.index.getStorageSync(n + "_" + t),
        a = i.data;
      return i.date != f() && p(n, a = 0, "date"), a
    }
    return o.index.getStorageSync(n + "_" + t)
  },
  p = function n(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
      i = arguments.length > 2 ? arguments[2] : void 0,
      a = getApp().globalData.appid;
    if (!i) return o.index.setStorageSync(e + "_" + a, t);
    n(e, {
      data: t,
      date: f()
    })
  },
  h = function() {
    var n = t(e().mark((function n(t) {
      var i;
      return e().wrap((function(n) {
        for (;;) switch (n.prev = n.next) {
          case 0:
            return i = getApp().globalData.videoAd, n.abrupt("return", (!i && m() && (i = o.index.createRewardedVideoAd({
              adUnitId: "adunit-eb77c5d5098d3bed"
            }), getApp().globalData.videoAd = i), new Promise((function(n, e) {
              i ? (t || i.load().then((function() {
                o.index.hideLoading(), i.show()
              })).catch((function(n) {
                e(!1)
              })), i.onError((function(n) {
                console.log("err", n), e(n.errCode)
              })), i.onClose((function(e) {
                o.index.hideLoading(), e.isEnded ? n(!0) : n(!1)
              }))) : e(!1)
            }))));
          case 2:
          case "end":
            return n.stop()
        }
      }), n)
    })));
    return function(e) {
      return n.apply(this, arguments)
    }
  }(),
  m = function() {
    return !0
  };
exports.adReport = function(e, t) {
  o.index.login({
    success: function(o) {
      i.api.adReport({
        data: n(n({}, e), {}, {
          code: o.code,
          sopenid: getApp().globalData.code,
          anonymous_code: o.anonymousCode,
          report_time: Math.round((new Date).getTime() / 1e3),
          type: 1 != t && 2 != t ? 11 : t,
          ad_err: 1 == t ? 0 : t
        })
      })
    }
  })
}, exports.chooseImage = function n(e) {
  return new Promise((function(t, a) {
    var d = "scope.camera",
      s = "请授权后上传图片";
    r(d, s, (function() {
      var r = [];
      o.index.chooseImage({
        count: e,
        success: function(n) {
          o.index.showLoading({
            title: "上传中..."
          });
          var e = 0;
          n.tempFilePaths.forEach((function(u) {
            i.api.getUploadToken().then((function(i) {
              c(i, u).then((function(a) {
                ++e === n.tempFilePaths.length && (t(r), o.index.hideLoading()), 200 === a.statusCode && r.push(i.img_http + JSON.parse(a.data).key)
              })).catch((function(n) {
                o.index.hideLoading(), a(n), console.log(n)
              }))
            }))
          }))
        },
        fail: function(i) {
          console.log(i), 10200 === i.errNo && u(d, s, (function() {
            n(e).then((function(n) {
              t(n)
            })).catch((function(n) {
              a(n)
            }))
          })), o.index.hideLoading(), a(i)
        }
      })
    }))
  }))
}, exports.delStorage = function(n) {
  var e = getApp().globalData.appid;
  return o.index.removeStorageSync(n + "_" + e)
}, exports.downloadFile = function(n, e) {
  return new Promise((function(e, t) {
    var o = "请授权后保存图片到本地相册",
      i = "scope.writePhotosAlbum";
    r(i, o, (function(a) {
      if (console.log("userAuthorize noSetting", a), a) return t(0);
      n.includes(".mp4") ? l(i, o, n).then((function(n) {
        e()
      })).catch((function(n) {
        console.log("downloadVideo err", n), t(n)
      })) : s(i, o, n).then((function(n) {
        e()
      })).catch((function(n) {
        console.log("downloadImage err", n), t(n)
      }))
    }))
  }))
}, exports.getOpenid = function(n) {
  var e = getApp();
  return new Promise((function(t, i) {
    var a = e.globalData.openid || g("openid");
    n && t(a), a ? (e.globalData.openid = a, e.globalData.unionid = g("unionid"), t(a)) : o.index.login({
      success: function(n) {
        o.index.request({
          url: e.globalData.host + "miniapi/User/getUserOpenid",
          method: "GET",
          data: {
            appid: e.globalData.appid,
            code: n.code
          },
          success: function(n) {
            console.log(n), p("openid", n.data.data.openid), p("unionid", n.data.data.unionid), e.globalData.unionid = n.data.data.unionid, e.globalData.openid = n.data.data.openid, t(n.data.data.openid)
          },
          fail: function(n) {
            console.log(n)
          }
        })
      },
      fail: function(n) {
        console.log(n)
      }
    })
  }))
}, exports.getShareData = function(n) {
  var e;
  return (null == (e = [{
    class: 1,
    title: "壁纸"
  }, {
    class: 2,
    title: "头像"
  }, {
    class: 3,
    title: "表情"
  }, {
    class: 4,
    title: "背景"
  }, {
    class: 5,
    title: "动态壁纸"
  }].find((function(e) {
    return e.class == n
  }))) ? void 0 : e.title) || "原图"
}, exports.getStorage = g, exports.img_config = d, exports.initRewardVideo = h, exports.playVideo = function(n) {
  m() ? h().then((function(e) {
    n(e ? 1 : 2)
  })).catch((function(e) {
    n(e)
  })) : (console.log("no ad"), n && n(!0))
}, exports.refuseAuth = function(n) {
  o.index.showModal({
    title: "温馨提示",
    content: "为了更好体验小程序，请授权用户信息权限",
    success: function(n) {
      if (n.confirm) {
        var e = "scope.userInfo";
        ! function(n, e) {
          o.index.getSetting({
            success: function(t) {
              console.log(t), t.authSetting[n] || void 0 === t.authSetting[n] ? a() : !1 === t.authSetting[n] && e && e()
            },
            fail: function(n) {
              console.log("getSetting 调用失败", n)
            }
          })
        }(e, (function() {
          o.index.openSetting({
            success: function(n) {
              n.authSetting[e] && a()
            }
          })
        }))
      }
    }
  })
}, exports.setStorage = p;