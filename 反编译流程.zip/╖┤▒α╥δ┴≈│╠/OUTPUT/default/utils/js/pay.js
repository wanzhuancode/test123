var n = require("../../common/vendor.js"),
  o = require("../../service/api.js"),
  e = !1,
  t = 0,
  i = function(o, i) {
    var r = 0,
      d = setInterval((function() {
        a(o, (function(a) {
          r++, 1 == t ? (i && i(t), clearInterval(d)) : r >= 10 && (e = !1, n.index.hideLoading(), t = 2, i && i(t, o), clearInterval(d))
        }))
      }), 3e3)
  },
  a = function(i, a) {
    t = 0, o.api.queryOrder({
      data: {
        out_order_no: i
      }
    }).then((function(o) {
      console.log(o), 1 === o.pay_status ? (n.index.hideLoading(), t = 1, e = !1, getApp().globalData.activity = 0, a && a(t)) : a && a(t)
    })).catch((function(n) {
      t = 2, e = !1, a && a(t)
    }))
  };
exports.payMixin = function(t, a) {
  e || function(t) {
    return e = !0, new Promise((function(i, a) {
      n.index.showLoading({
        title: "订单生成中..."
      }), o.api.getOrder({
        data: t
      }).then((function(n) {
        e = !1, i(n)
      })).catch((function(o) {
        n.index.hideLoading(), a(o), console.log("订单查询失败", o), e = !1, n.index.showToast({
          title: "订单创建失败",
          icon: "none"
        })
      }))
    }))
  }(t).then((function(o) {
    console.log(o), tt.requestOrder({
      data: o.data.data,
      byteAuthorization: o.data.byte_Authorization,
      success: function(e) {
        console.log(e), n.index.hideLoading(), e.orderId ? tt.getOrderPayment({
          orderId: e.orderId,
          success: function(e) {
            console.log(e), "getOrderPayment:ok" === e.errMsg && (n.index.showLoading({
              title: "支付查询中..."
            }), i(o.out_order_no, a))
          },
          fail: function(o) {
            console.log(o), n.index.showToast({
              title: "支付失败",
              icon: "none"
            })
          }
        }) : n.index.showToast({
          title: "订单创建失败",
          icon: "none"
        })
      },
      fail: function(o) {
        console.log(o), n.index.hideLoading(), n.index.showToast({
          title: "订单创建失败",
          icon: "none"
        })
      }
    })
  }))
}, exports.queryOrder = a;