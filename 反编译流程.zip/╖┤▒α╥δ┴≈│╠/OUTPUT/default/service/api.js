var e = require("../common/vendor.js"),
  a = require("../utils/js/crypto-js.min.js"),
  n = require("../utils/js/common.js"),
  r = {};
[{
  desc: "首页列表",
  name: "home",
  url: "miniapi/Product/home",
  loading: !1,
  encrypt: !0
}, {
  desc: "推荐数据展示数据",
  name: "recommend",
  url: "miniapi/Product/recommend",
  loading: !1,
  encrypt: !0
}, {
  desc: "用户账号数据",
  name: "accountData",
  url: "miniapi/Product/accountData",
  loading: !1,
  encrypt: !0
}, {
  desc: "分页数据 （落地用户资源页数据获取）",
  name: "pageIndex",
  url: "miniapi/Product/pageIndex",
  loading: !1,
  encrypt: !0
}, {
  desc: "专辑列表获取（分页）",
  name: "albumList",
  url: "miniapi/Product/albumList",
  loading: !1,
  encrypt: !0
}, {
  desc: "单专辑信息获取（path直接落地时候）",
  name: "albumData",
  url: "miniapi/Product/albumData",
  loading: !1,
  encrypt: !0
}, {
  desc: "单专辑数据获取（分页）",
  name: "albumDataPage",
  url: "miniapi/Product/albumDataPage",
  loading: !1,
  encrypt: !0
}, {
  desc: "单张图资源信息获取",
  name: "singleData",
  url: "miniapi/Product/singleData",
  loading: !1,
  encrypt: !0
}, {
  desc: "小程序内上传七牛token获取",
  name: "getUploadToken",
  url: "miniapi/QnUpload/getUploadToken",
  loading: !1,
  encrypt: !0
}, {
  desc: "小程序创作者申请",
  name: "freeBack",
  url: "miniapi/Product/freeBack",
  loading: !1,
  encrypt: !0
}, {
  desc: "小程序内用户反馈",
  name: "promotion",
  url: "miniapi/Product/promotion",
  loading: !1,
  encrypt: !0
}, {
  desc: "小程序用户初始化",
  name: "appUserData",
  url: "miniapi/Cash/appUserData",
  loading: !1,
  encrypt: !0
}, {
  desc: "用户头像昵称更新",
  name: "userInfo",
  url: "miniapi/User/userInfo",
  loading: !1,
  encrypt: !1
}, {
  desc: "收银台获取",
  name: "cashDesk",
  url: "miniapi/Cash/cashDesk",
  loading: !1,
  encrypt: !0
}, {
  desc: "用户消费上报",
  name: "playReport",
  url: "miniapi/Order/playReport",
  loading: !1,
  encrypt: !0
}, {
  desc: "广告上报",
  name: "adReport",
  url: "miniapi/Order/adReport",
  loading: !1,
  encrypt: !0
}, {
  desc: "获取商品列表 ",
  name: "goodsList",
  url: "miniapi/Order/goodsList",
  loading: !1,
  encrypt: !0
}, {
  desc: "获取用户订单列表 ",
  name: "getUserOrderList",
  url: "miniapi/Order/getUserOrderList",
  loading: !1,
  encrypt: !0
}, {
  desc: "获取订单数据",
  name: "getOrder",
  url: "miniapi/Order/getOrder",
  loading: !1,
  encrypt: !0
}, {
  desc: "订单查询 ",
  name: "queryOrder",
  url: "miniapi/Order/queryOrder",
  loading: !1,
  encrypt: !0
}, {
  desc: "白名单",
  name: "whiteBind",
  url: "miniapi/product/whiteBind",
  loading: !1,
  encrypt: !0
}].forEach((function(a) {
  r[a.name] = function(r) {
    var o = r || {},
      c = o.data,
      p = o.header;
    o.dataType;
    return c = c || {}, new Promise((function(r, o) {
      try {
        !1 !== a.loading && e.index.showLoading(), n.getOpenid(a.notOpenid).then((function(n) {
          var o = getApp().globalData,
            s = c;
          if (a.encrypt) {
            n && (s.openid = n), s.appid = o.appid, s.unionid = o.unionid, s.ver = o.ver, s.min_push = o.min_push, s.scene = e.index.getLaunchOptionsSync().scene, console.log(a.name, s);
            var u = d();
            s = {
              requestData: t(JSON.stringify(c), u, a.decodekey),
              iv: u
            }
          }
          e.index.request({
            url: o.host + a.url,
            method: a.method || "GET",
            data: s,
            header: p,
            timeout: 3e4,
            success: function(e) {
              if (200 == e.statusCode && null != e.data && 0 != e.data.code) {
                var n = e;
                if (a.encrypt && e.data.data && e.data.data.iv) return n = i(e.data.data.data, e.data.data.iv, a.decodekey), n = JSON.parse(n), void r(n);
                r(n.data)
              } else r(e)
            },
            fail: function(e) {
              console.error("api error：" + a.url, e), r(e)
            },
            complete: function() {
              !1 !== a.loading && e.index.hideLoading()
            }
          })
        }))
      } catch (a) {
        console.error("方法异常：", a), r({
          message: "请求错误"
        }), "网络连接失败，请稍后重试", e.index.showToast({
          title: "网络连接失败，请稍后重试",
          duration: 1500,
          icon: "none"
        })
      }
    }))
  }
}));
var i = function(e, n) {
    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "WAG0JIUGYALACVJF",
      i = a.CryptoJS.enc.Utf8.parse(r),
      t = a.CryptoJS.enc.Utf8.parse(n);
    return a.CryptoJS.AES.decrypt(e, i, {
      iv: t,
      mode: a.CryptoJS.mode.CBC,
      padding: a.CryptoJS.pad.Pkcs7
    }).toString(a.CryptoJS.enc.Utf8)
  },
  t = function(e, n) {
    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "WAG0JIUGYALACVJF",
      i = a.CryptoJS.enc.Utf8.parse(r),
      t = a.CryptoJS.enc.Utf8.parse(n);
    return a.CryptoJS.AES.encrypt(e, i, {
      iv: t,
      mode: a.CryptoJS.mode.CBC,
      padding: a.CryptoJS.pad.Pkcs7
    }).toString()
  },
  d = function() {
    for (var e = "", a = ["1", "2", "4", "5", "3", "8", "0", "7", "9", "6", "A", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "S", "D", "F", "G", "H", "J", "K", "L", "q", "w", "S", "e", "a", "s", "d", "z", "x", "c", "v", "f", "r", "t", "g", "b", "y", "h", "n", "m", "j", "u", "i", "o", "k", "l", "p"], n = 0; n < 16; n++) e += a[(Math.random() * (a.length - 1)).toFixed(0)];
    return e
  };
exports.api = r;