var a = require("../../@babel/runtime/helpers/toConsumableArray"),
  t = require("../../@babel/runtime/helpers/defineProperty"),
  i = require("../../common/vendor.js"),
  n = getApp(),
  e = {
    components: {
      navback: function() {
        return "../../components/navBack.js"
      },
      complain: function() {
        return "../../components/complain.js"
      },
      myImage: function() {
        return "../../components/my-image.js"
      },
      empty: function() {
        return "../../components/empty.js"
      }
    },
    data: function() {
      return t(t({
        alb_id: 0,
        acc_id: 0,
        type: 0,
        sort: 1,
        pageIndex: 1,
        albumPage: 1,
        page: 1,
        loading: !0,
        noAlbum: !1,
        albumLoading: !1,
        noData: !1,
        albumList: [],
        imageList: [],
        listData: [],
        albData: {},
        config: {},
        userData: "",
        loadingStatus: "more"
      }, "config", n.globalData.config), "img_config", n.globalData.img_config || {})
    },
    onShareAppMessage: function(a) {
      var t = n.globalData.code,
        i = "/pages/author/author?acc_id=".concat(this.acc_id || 1, "&code=").concat(t, "&alb_id=").concat(this.alb_id, "&page_path=album");
      return {
        channel: a.channel,
        imageUrl: !1,
        title: "点击下载同款原图",
        path: i,
        extra: {
          withVideoId: !0
        },
        success: function(a) {}
      }
    },
    onLoad: function(a) {
      a.alb_id ? (this.alb_id = a.alb_id || 0, this.acc_id = a.acc_id || 0, this.getAlbumInfo()) : i.index.redirectTo({
        url: "/pages/index/index"
      })
    },
    methods: {
      getAlbumInfo: function() {
        var a = this;
        i.index.showLoading({
          title: "加载中..."
        }), this.$api.albumData({
          data: {
            alb_id: this.alb_id
          }
        }).then((function(t) {
          var n, e = null == (n = t.data) ? void 0 : n.data;
          if (!e) return i.index.redirectTo({
            url: "/pages/index/index"
          }), !1;
          a.albData = e, a.albumList.push(e), a.getAlbumList(), a.getAlbumData()
        })).finally((function(a) {
          i.index.hideLoading()
        }))
      },
      changeAlbum: function(a) {
        this.pageIndex = 1, this.alb_id = a.alb_id, this.albData = a, this.imageList = [], this.listData = [], this.loading = !0, this.noData = !1, this.getAlbumData()
      },
      binAlbumScroll: function() {
        var a = this;
        this.$nextTick((function() {
          if (a.noAlbum || a.albumLoading) return !1;
          a.albumLoading = !0, a.albumPage++, a.getAlbumList()
        }))
      },
      getAlbumList: function() {
        var t = this;
        this.$api.albumList({
          data: {
            page: this.albumPage,
            acc_id: this.acc_id
          }
        }).then((function(i) {
          console.log(i), 0 == i.data.list.length && (t.noAlbum = !0);
          var n = i.data.list.findIndex((function(a) {
            return a.alb_id == t.alb_id
          }));
          i.data.list.splice(n, 1), t.albumList = [].concat(a(t.albumList), a(i.data.list))
        })).finally((function(a) {
          t.albumLoading = !1, i.index.hideLoading()
        }))
      },
      getAlbumData: function() {
        var t = this,
          n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.alb_id,
          e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.acc_id;
        i.index.showLoading({
          title: "资源加载中..."
        }), this.$api.albumDataPage({
          data: {
            alb_id: n,
            acc_id: e,
            sort: this.albData.def_sort || 1,
            page: this.pageIndex
          }
        }).then((function(n) {
          if (t.config = n.config, !n.data) return i.index.redirectTo({
            url: "/pages/index/index"
          });
          var e = t.listData.length;
          n.data.list.forEach((function(a, i) {
            for (var n = 0; n < 4; n++)(i + e) % 4 === n && (t.imageList[n] ? t.imageList[n].push(a) : t.imageList[n] = [a])
          })), t.listData = [].concat(a(t.listData), a(n.data.list)), i.index.hideLoading(), 0 == n.data.list.length ? (t.loadingStatus = "no-more", i.index.showToast({
            title: "暂无更多资源",
            icon: "none"
          })) : t.loadingStatus = "more"
        })).catch((function(a) {
          i.index.hideLoading(), t.loadingStatus = "no-more"
        }))
      },
      bindStatement: function() {
        i.index.showModal({
          title: "声明",
          content: "所有素材均由创作者上传及负责，部分素材来源网络，如有侵权，请联系我们进行删除处理",
          showCancel: !1
        })
      },
      selectImg: function(a) {
        var t = this.listData.filter((function(t) {
            return t.class === a.class
          })),
          e = t.findIndex((function(t) {
            return a.res_id === t.res_id
          })),
          o = Math.floor(e / 30),
          l = t.slice(30 * o, 30 * (o + 1)),
          s = "/pages/preview/preview?image=" + encodeURIComponent(JSON.stringify(a));
        2 == a.class && (n.globalData.userData = this.userData, s = "/pages/preview/avatar?image=" + encodeURIComponent(JSON.stringify(a))), n.globalData.imageList = l, i.index.navigateTo({
          url: "".concat(s, "&alb_id=").concat(this.albData.alb_id)
        })
      },
      binScroll: function() {
        var a = this;
        console.log(this.loadingStatus), this.$nextTick((function() {
          "more" == a.loadingStatus && (a.loadingStatus = "loading", a.pageIndex++, a.getAlbumData())
        }))
      }
    }
  };
Array || (i.resolveComponent("navback") + i.resolveComponent("my-image") + i.resolveComponent("empty") + i.resolveComponent("complain"))();
var o = i._export_sfc(e, [
  ["render", function(a, t, n, e, o, l) {
    var s = this;
    return i.e({
      a: i.f(o.albumList, (function(t, n, e) {
        return i.e({
          a: t.cover.list[0]
        }, t.cover.list[0] ? i.e({
          b: t.alb_id == s.alb_id
        }, (t.alb_id, s.alb_id, {}), {
          c: a.$link(t.cover.list[0].img),
          d: i.t(t.name)
        }) : {}, {
          e: n,
          f: i.o((function(a) {
            return l.changeAlbum(t)
          }), n)
        })
      })),
      b: i.o((function() {
        return l.binAlbumScroll && l.binAlbumScroll.apply(l, arguments)
      })),
      c: i.t(o.albData.name),
      d: o.imageList.length > 0
    }, o.imageList.length > 0 ? {
      e: i.f(o.imageList, (function(a, t, n) {
        return {
          a: i.f(a, (function(a, t, e) {
            return {
              a: t,
              b: i.o((function(i) {
                return l.selectImg(a, t)
              }), t),
              c: "5f6e1476-1-" + n + "-" + e,
              d: i.p({
                img: a,
                col: "4"
              })
            }
          })),
          b: t
        }
      }))
    } : {}, {
      f: i.o((function() {
        return l.binScroll && l.binScroll.apply(l, arguments)
      }))
    })
  }]
]);
e.__runtimeHooks = 2, wx.createPage(o);