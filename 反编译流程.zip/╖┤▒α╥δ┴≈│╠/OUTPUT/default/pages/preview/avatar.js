var t = require("../../@babel/runtime/helpers/toConsumableArray"),
  e = require("../../common/vendor.js"),
  n = require("../../utils/js/common.js"),
  i = getApp(),
  a = {
    components: {
      complain: function() {
        return "../../components/complain.js"
      },
      popup: function() {
        return "../../components/popup.js"
      },
      navBack: function() {
        return "../../components/navBack.js"
      },
      experience: function() {
        return "../../components/experience.js"
      },
      downView: function() {
        return "../../components/down-view.js"
      }
    },
    data: function() {
      return {
        os: e.index.getSystemInfoSync().osName,
        current: 0,
        resId: "",
        imageList: [],
        currentImg: {},
        userData: {},
        showList: !0,
        showDownLoad: !1,
        playing: !1,
        showVideo: !1,
        type: 1,
        alb_id: 0,
        videoHeight: {},
        activity: 0,
        pageIndex: 1,
        img_conig: {},
        downType: "img"
      }
    },
    onShareAppMessage: function(t) {
      var e = this.currentImg.class,
        a = n.getShareData(e),
        o = i.globalData.code,
        r = "/pages/author/author?acc_id=".concat(this.userData.acc_id || 1, "&code=").concat(o, "&res_id=").concat(this.currentImg.res_id, "&page_path=avatar");
      return {
        channel: t.channel,
        imageUrl: !1,
        title: "点击下载同款" + a,
        path: r,
        extra: {
          withVideoId: !0
        },
        success: function(t) {}
      }
    },
    onLoad: function(t) {
      if (this.userData = i.globalData.accData || {}, t.image) {
        var n = JSON.parse(decodeURIComponent(t.image));
        this.resId = n.res_id, this.getResData(n.res_id)
      }
      this.type = t.type || 1, t.res_id && this.getResData(t.res_id), t.image || t.res_id || e.index.redirectTo({
        url: "/pages/index/index"
      })
    },
    onShow: function() {
      this.activity = i.globalData.activity
    },
    methods: {
      getResData: function(t) {
        var n = this;
        this.$api.singleData({
          data: {
            res_id: t
          }
        }).then((function(t) {
          if (console.log(t), !t.data.data) return e.index.redirectTo({
            url: "/pages/index/index"
          });
          n.currentImg = t.data.data, n.resId = t.data.data.res_id, n.imageList = i.globalData.imageList || [], 0 === n.imageList.length && n.getPageData()
        }))
      },
      swiperChange: function(t) {
        var e = this,
          n = this.imageList.length,
          i = this.imageList.findIndex((function(t) {
            return t.res_id == e.currentImg.res_id
          }));
        (i += t) < 0 ? i = n - 1 : i == n && (i = 0), this.currentImg = this.imageList[i]
      },
      previewLoad: function(t) {
        var e = t.currentTarget.dataset.id;
        console.log(e), this.videoHeight["img" + e] = t.detail.height, console.log(this.videoHeight)
      },
      bindPause: function() {
        this.showVideo = !1, this.playing = !1
      },
      bindScroll: function(t) {
        this.currentImg = t
      },
      controlVideo: function(t) {
        var n = e.index.createVideoContext("video" + t);
        this.showVideo = !0, this.playing ? (this.playing = !1, n.pause()) : (this.playing = !0, n.play())
      },
      bindDownload: function(t) {
        this.showDownLoad = !0, this.downType = t || "img"
      },
      bindBack: function() {
        getCurrentPages().length > 1 ? e.index.navigateBack() : e.index.redirectTo({
          url: "/pages/index/index"
        })
      },
      openVip: function() {
        this.activity = 0, i.globalData.activity = 2, this.$refs.down.openVip()
      },
      closePop: function() {
        i.globalData.activity = 0, this.activity = 0
      },
      getMoreData: function() {},
      getPageData: function() {
        var e = this;
        this.$api.pageIndex({
          data: {
            acc_id: this.userData.acc_id,
            page: this.pageIndex,
            type: this.type || this.currentImg.type,
            sort: 1
          }
        }).then((function(n) {
          console.log(n), e.config = n.config, n.data ? (e.loadingStatus = "loading", e.imageList || (e.imageList = []), e.imageList = [].concat(t(e.imageList), t(n.data.list)), (!n.data.list || n.data.list.length < 10) && (e.noData = !0, e.loadingStatus = "nomore")) : (e.noData = !0, e.loadingStatus = "nomore")
        })).catch((function(t) {
          console.log("err", t)
        }))
      },
      toAuthor: function() {
        console.log("sss"), e.index.redirectTo({
          url: "/pages/author/author?acc_id=" + this.userData.acc_id + "&show_type=" + this.currentImg.class
        })
      }
    }
  };
Array || (e.resolveComponent("navBack") + e.resolveComponent("downView") + e.resolveComponent("experience"))();
var o = e._export_sfc(a, [
  ["render", function(t, n, i, a, o, r) {
    return e.e({
      a: o.userData.app_head_img
    }, o.userData.app_head_img ? {
      b: o.userData.app_head_img,
      c: e.t(o.userData.app_name),
      d: e.o((function() {
        return r.toAuthor && r.toAuthor.apply(r, arguments)
      })),
      e: e.o((function() {
        return r.toAuthor && r.toAuthor.apply(r, arguments)
      }))
    } : {}, {
      f: o.currentImg && o.currentImg.img
    }, o.currentImg && o.currentImg.img ? e.e({
      g: e.o((function(t) {
        return r.swiperChange(-1)
      })),
      h: t.$img_config.domain + o.currentImg.img + t.$img_config.img_thumb,
      i: e.o((function(t) {
        return r.swiperChange(1)
      })),
      j: e.t(2 == o.currentImg.class ? "头像" : "表情包"),
      k: e.o((function() {
        return r.bindDownload && r.bindDownload.apply(r, arguments)
      })),
      l: 3 == o.currentImg.class && o.currentImg.video_url
    }, 3 == o.currentImg.class && o.currentImg.video_url ? {
      m: e.o((function(t) {
        return r.bindDownload("video_url")
      }))
    } : {}) : {}, {
      n: o.imageList.length > 0
    }, o.imageList.length > 0 ? {
      o: e.o((function() {
        return r.toAuthor && r.toAuthor.apply(r, arguments)
      })),
      p: e.f(o.imageList, (function(n, i, a) {
        return {
          a: t.$link(n.img),
          b: n.res_id == o.currentImg.res_id ? 1 : "",
          c: i,
          d: e.o((function(t) {
            return r.bindScroll(n)
          }), i)
        }
      })),
      q: e.o((function() {
        return r.getMoreData && r.getMoreData.apply(r, arguments)
      }))
    } : {}, {
      r: e.sr("down", "851999ae-1"),
      s: e.o((function(t) {
        return o.showDownLoad = t
      })),
      t: e.p({
        "res-id": o.resId,
        "down-type": o.downType,
        "alb-id": o.alb_id,
        img: o.currentImg,
        show: o.showDownLoad
      }),
      v: e.o(r.closePop),
      w: e.o((function(t) {
        return r.openVip(!1)
      })),
      x: e.p({
        show: o.activity > 0
      })
    })
  }]
]);
a.__runtimeHooks = 2, wx.createPage(o);