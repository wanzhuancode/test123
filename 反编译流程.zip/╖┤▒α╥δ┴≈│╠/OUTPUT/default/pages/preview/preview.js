var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  n = require("../../@babel/runtime/helpers/objectSpread2"),
  i = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../common/vendor.js"),
  r = require("../../utils/js/common.js"),
  a = getApp(),
  o = {
    components: {
      complain: function() {
        return "../../components/complain.js"
      },
      popup: function() {
        return "../../components/popup.js"
      },
      experience: function() {
        return "../../components/experience.js"
      },
      downView: function() {
        return "../../components/down-view.js"
      }
    },
    data: function() {
      return {
        os: t.index.getSystemInfoSync().osName,
        accData: a.globalData.accData || {},
        current: 0,
        resId: "",
        imageList: [],
        swiperList: [],
        showList: !0,
        showDownLoad: !1,
        playing: !1,
        showVideo: !1,
        type: 1,
        alb_id: 0,
        videoHeight: {},
        activity: 0,
        img_config: a.globalData.img_config || {},
        currentImage: {},
        downType: "img"
      }
    },
    computed: {
      currentTit: function() {
        return r.getShareData(this.currentImage.class)
      }
    },
    onShareAppMessage: function(e) {
      var n = this.currentImage.class,
        i = r.getShareData(n),
        t = a.globalData,
        o = t.acc_id,
        s = t.code,
        c = "/pages/author/author?acc_id=".concat(o || 1, "&code=").concat(s, "&res_id=").concat(this.resId, "&page_path=preview");
      return {
        channel: e.channel,
        imageUrl: !1,
        title: "点击下载同款" + i,
        path: c,
        extra: {
          withVideoId: !0
        },
        success: function(e) {}
      }
    },
    onLoad: function(e) {
      if (a.globalData.imageList.length > 0 && (this.imageList = a.globalData.imageList), e.image) {
        var n = JSON.parse(decodeURIComponent(e.image));
        this.resId = n.res_id, this.previewCurrent(n)
      }
      this.alb_id = e.alb_id || 0, this.type = e.type || 1, e.res_id && this.getResData(e.res_id), e.image || e.res_id || t.index.redirectTo({
        url: "/pages/index/index"
      })
    },
    onShow: function() {
      this.activity = a.globalData.activity
    },
    methods: {
      previewCurrent: function(r) {
        var a = this;
        return i(e().mark((function i() {
          var o;
          return e().wrap((function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!r.img.includes(".mp4")) {
                  e.next = 4;
                  break
                }
                a.currentImage = r, e.next = 16;
                break;
              case 4:
                return t.index.showLoading({
                  title: "加载中..."
                }), e.prev = 5, e.next = 8, t.index.getImageInfo({
                  src: a.$img_config.down_domain + r.img
                });
              case 8:
                o = e.sent, a.currentImage = n(n({}, r), {}, {
                  current: o.path
                }), e.next = 15;
                break;
              case 12:
                e.prev = 12, e.t0 = e.catch(5), t.index.showToast({
                  title: "加载失败"
                });
              case 15:
                t.index.hideLoading();
              case 16:
              case "end":
                return e.stop()
            }
          }), i, null, [
            [5, 12]
          ])
        })))()
      },
      getResData: function(e) {
        var n = this;
        this.$api.singleData({
          data: {
            res_id: e
          }
        }).then((function(e) {
          if (console.log(e), !e.data) return t.index.redirectTo({
            url: "/pages/index/index"
          });
          n.previewCurrent(e.data.data), n.resId = e.data.data.res_id
        }))
      },
      previewLoad: function(e) {
        e.currentTarget.dataset.id;
        var n = e.detail.width,
          i = t.index.getSystemInfoSync().screenWidth;
        this.videoHeight = e.detail.height * (i / n)
      },
      bindPause: function() {
        this.showVideo = !1, this.playing = !1
      },
      bindScroll: function(e) {
        this.resId = e.res_id, this.previewCurrent(e), this.showVideo = !1, this.playing = !1
      },
      controlVideo: function(e) {
        var n = t.index.createVideoContext("video" + e);
        this.showVideo = !0, this.playing ? (this.playing = !1, n.pause()) : (this.playing = !0, n.play())
      },
      bindDownload: function(e) {
        this.showDownLoad = !0, this.downType = e || "img"
      },
      bindBack: function() {
        getCurrentPages().length > 1 ? t.index.navigateBack() : t.index.redirectTo({
          url: "/pages/index/index"
        })
      },
      openVip: function() {
        this.activity = 0, a.globalData.activity = 2, this.$refs.down.openVip()
      },
      closePop: function() {
        a.globalData.activity = 0, this.activity = 0
      }
    }
  };
Array || (t.resolveComponent("downView") + t.resolveComponent("experience"))();
var s = t._export_sfc(o, [
  ["render", function(e, n, i, r, a, o) {
    return t.e({
      a: a.currentImage.img
    }, a.currentImage.img ? t.e({
      b: a.currentImage.img.includes(".mp4")
    }, a.currentImage.img.includes(".mp4") ? t.e({
      c: a.showVideo
    }, a.showVideo ? {
      d: "video" + a.currentImage.res_id,
      e: a.showVideo ? 1 : 0,
      f: a.videoHeight + "px",
      g: t.o((function() {
        return o.bindPause && o.bindPause.apply(o, arguments)
      })),
      h: e.$img_config.domain + a.currentImage.img
    } : {}, {
      i: a.showVideo ? 0 : 1,
      j: e.$link(a.currentImage.img),
      k: t.o((function() {
        return o.previewLoad && o.previewLoad.apply(o, arguments)
      })),
      l: !a.playing,
      m: t.o((function(e) {
        return o.controlVideo(a.currentImage.res_id)
      })),
      n: a.playing,
      o: t.o((function(e) {
        return o.controlVideo(a.currentImage.res_id)
      }))
    }) : 1 == a.currentImage.class ? {
      q: a.currentImage.current
    } : {
      r: 4 == a.currentImage.class ? 1 : "",
      s: a.currentImage.current
    }, {
      p: 1 == a.currentImage.class,
      t: 5 == a.currentImage.class ? 1 : ""
    }) : {}, {
      v: a.imageList.length > 0
    }, a.imageList.length > 0 ? {
      w: t.t(a.showList ? "收起" : "展开"),
      x: a.showList ? 1 : "",
      y: t.o((function(e) {
        return a.showList = !a.showList
      })),
      z: t.f(a.imageList, (function(n, i, r) {
        return t.e({
          a: e.$link(n.img),
          b: n.img.includes(".mp4")
        }, (n.img.includes(".mp4"), {}), {
          c: n.res_id == a.resId
        }, (n.res_id, a.resId, {}), {
          d: t.n({
            background: 3 == n.class || 4 == n.class
          }),
          e: n.res_id == a.resId ? 1 : "",
          f: i,
          g: t.o((function(e) {
            return o.bindScroll(n)
          }), i)
        })
      })),
      A: a.showList ? "200rpx" : 0
    } : {}, {
      B: 3 == a.currentImage.class && a.currentImage.video_url
    }, 3 == a.currentImage.class && a.currentImage.video_url ? {
      C: t.t(o.currentTit),
      D: t.o((function() {
        return o.bindDownload && o.bindDownload.apply(o, arguments)
      })),
      E: t.o((function(e) {
        return o.bindDownload("video_url")
      }))
    } : {
      F: t.t(o.currentTit),
      G: t.o((function() {
        return o.bindDownload && o.bindDownload.apply(o, arguments)
      }))
    }, {
      H: t.o((function() {
        return o.bindBack && o.bindBack.apply(o, arguments)
      })),
      I: 3 == a.currentImage.class && a.currentImage.video_url ? 1 : "",
      J: t.sr("down", "e22254b0-0"),
      K: t.o((function(e) {
        return a.showDownLoad = e
      })),
      L: t.p({
        "res-id": a.resId,
        "down-type": a.downType,
        "alb-id": a.alb_id,
        img: a.currentImage,
        show: a.showDownLoad
      }),
      M: t.o(o.closePop),
      N: t.o((function(e) {
        return o.openVip(!1)
      })),
      O: t.p({
        show: a.activity > 0
      })
    })
  }]
]);
o.__runtimeHooks = 2, wx.createPage(s);