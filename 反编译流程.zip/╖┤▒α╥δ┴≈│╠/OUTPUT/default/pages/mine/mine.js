var t = require("../../common/vendor.js"),
  e = require("../../utils/js/common.js"),
  n = getApp(),
  i = {
    data: function() {
      return {
        os: t.index.getSystemInfoSync().osName,
        SDKVersion: "",
        ios: t.index.getSystemInfoSync().platform.toLowerCase().includes("ios"),
        navTop: t.index.getSystemInfoSync().statusBarHeight + "px",
        kefuData: {},
        userData: {},
        userInfo: null,
        appid_uid: 0,
        vip: 0,
        pay_status: 0,
        activity: 0
      }
    },
    components: {
      navBack: function() {
        return "../../components/navBack.js"
      },
      complain: function() {
        return "../../components/complain.js"
      },
      popup: function() {
        return "../../components/popup.js"
      },
      experience: function() {
        return "../../components/experience.js"
      }
    },
    onShareAppMessage: function() {
      return {
        imageUrl: !1,
        title: "点击下载同款原图",
        path: "/pages/index/index"
      }
    },
    onLoad: function() {
      t.index.showLoading({
        title: "加载中..."
      }), this.$nextTick((function() {
        t.index.hideLoading()
      }))
    },
    onShow: function() {
      this.getUserData()
    },
    methods: {
      goCreater: function() {
        t.index.navigateTo({
          url: "/pages/creater/creater"
        })
      },
      getUserData: function() {
        var t = this;
        this.$api.appUserData().then((function(i) {
          t.userInfo = e.getStorage("userInfo") || null, t.userData = i, t.vip = i.vip, t.vip > 0 ? t.activity = 0 : t.activity = n.globalData.activity
        })).catch((function(e) {
          t.activity = n.globalData.activity
        }))
      },
      getUserInfo: function(t) {
        console.log("getUserInfo", t), this.addUser({
          avatarUrl: t.detail.avatarUrl,
          nickName: "壁纸用户"
        })
      },
      addUser: function(t) {
        var i = this,
          o = n.globalData,
          a = o.openid,
          r = o.appid,
          s = o.unionid,
          c = o.ver;
        this.$api.userInfo({
          data: {
            headImg: t.avatarUrl,
            nickName: t.nickName,
            openid: a,
            appid: r,
            unionid: s,
            ver: c
          }
        }).then((function(n) {
          i.userData = n.data, i.vip = n.data.vip, i.userInfo = t, e.setStorage("userInfo", t)
        })).catch((function(t) {
          console.log(t)
        }))
      },
      openVip: function(e) {
        if (1 != n.globalData.config.check) {
          var i = "暂不支持开通此服务";
          this.ios && (i = "IOS用户" + i), this.ios || 2 == this.pay_status ? t.index.showToast({
            title: i,
            icon: "none"
          }) : 2 != this.pay_status ? (e || (this.activity = 0, n.globalData.activity = 2), t.index.navigateTo({
            url: "/pages/membership/membership"
          })) : t.index.showToast({
            title: i,
            icon: "none"
          })
        }
      },
      toQuestion: function() {
        t.index.navigateTo({
          url: "/pages/complain/question"
        })
      },
      toKeFu: function() {
        this.vip > 0 || this.goCreater()
      },
      quitAccount: function() {
        this.userInfo = null, e.delStorage("userInfo")
      },
      closePop: function() {
        n.globalData.activity = 0, this.activity = 0, console.log("activity", this.activity)
      },
      toOrder: function() {
        t.index.navigateTo({
          url: "/pages/order/order"
        })
      }
    }
  };
Array || (t.resolveComponent("experience") + t.resolveComponent("complain"))();
var o = t._export_sfc(i, [
  ["render", function(e, n, i, o, a, r) {
    return t.e({
      a: !a.userInfo
    }, a.userInfo ? t.e({
      h: a.userInfo.avatarUrl,
      i: t.t(a.userInfo.nickName),
      j: a.userData.vip > 0
    }, a.userData.vip > 0 ? {
      k: "http://min-cdn.xliii.cn/miniapp/juejinbizhi/ts_new/vip/order-" + a.vip + ".png?v=1.1"
    } : {}, {
      l: t.o((function() {
        return r.quitAccount && r.quitAccount.apply(r, arguments)
      })),
      m: a.userData.vip > 0
    }, a.userData.vip > 0 ? {
      n: t.t(a.userData.end_date)
    } : {}) : t.e({
      b: t.o((function() {
        return r.getUserInfo && r.getUserInfo.apply(r, arguments)
      })),
      c: t.o((function() {
        return r.getUserInfo && r.getUserInfo.apply(r, arguments)
      })),
      d: a.vip > 0
    }, a.vip > 0 ? {
      e: "http://min-cdn.xliii.cn/miniapp/juejinbizhi/ts_new/vip/order-" + a.vip + ".png?v=1.1"
    } : {}, {
      f: a.vip > 0
    }, a.vip > 0 ? {
      g: t.t(a.userData.end_date)
    } : {}), {
      o: t.o((function() {
        return r.goCreater && r.goCreater.apply(r, arguments)
      })),
      p: t.o((function() {
        return r.toQuestion && r.toQuestion.apply(r, arguments)
      })),
      q: t.o((function() {
        return r.toOrder && r.toOrder.apply(r, arguments)
      })),
      r: t.o(r.closePop),
      s: t.o((function(t) {
        return r.openVip(!1)
      })),
      t: t.p({
        show: a.activity > 0
      }),
      v: a.navTop
    })
  }],
  ["__scopeId", "data-v-c3ecab63"]
]);
i.__runtimeHooks = 2, wx.createPage(o);