var a = require("../../common/vendor.js"),
  t = getApp(),
  o = {
    components: {
      advert: function() {
        return "../../components/advert.js"
      }
    },
    data: function() {
      return {
        searchValue: "",
        showAdvert: !1,
        listData: [],
        recommendList: [],
        config: {},
        inputFocus: !1,
        qn_config: {}
      }
    },
    onLoad: function(o) {
      this.initHomeData(), console.log(t.globalData.inputFocus), this.inputFocus = t.globalData.inputFocus, o.white_bind && this.$api.whiteBind({
        data: {
          white_bind: o.white_bind
        }
      }).then((function(t) {
        console.log(t), setTimeout((function() {
          1 == t.data.status ? a.index.showModal({
            title: "温馨提示",
            content: "免广告体验特权已开启",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#e6645f"
          }) : a.index.showModal({
            title: "温馨提示",
            content: "绑定失败",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#e6645f"
          })
        }), 500)
      }))
    },
    onHide: function() {
      this.inputFocus = !1, t.globalData.inputFocus = !1, console.log(t.globalData.inputFocus)
    },
    onUnload: function() {
      this.inputFocus = !1, t.globalData.inputFocus = !1, console.log(t.globalData.inputFocus)
    },
    methods: {
      initHomeData: function() {
        var t = this;
        a.index.showLoading({
          title: "加载中..."
        }), this.$api.home().then((function(o) {
          console.log(o), t.listData = o.data.list, t.recommendList = o.data.recommend, a.index.hideLoading()
        }))
      },
      bindAuthor: function(t) {
        a.index.navigateTo({
          url: "/pages/author/author?acc_id=" + t.acc_id
        })
      },
      bindImage: function(t) {
        a.index.navigateTo({
          url: "/pages/preview/preview?image=" + encodeURIComponent(JSON.stringify(t))
        })
      },
      bindSearch: function() {
        var t = this;
        this.searchValue && this.$api.accountData({
          data: {
            code: this.searchValue
          }
        }).then((function(o) {
          if (o.data && o.data.acc_data) {
            var n = o.data.acc_data,
              e = o.data.show_data;
            1 == e.show_class ? a.index.navigateTo({
              url: "/pages/author/author?code=".concat(o.data.code, "&acc_id=").concat(n.acc_id, "&sort=").concat(n.def_sort, "&show_type=").concat(e.show_res_id)
            }) : 3 == e.show_class ? a.index.navigateTo({
              url: "/pages/author/author?code=".concat(o.data.code, "&acc_id=").concat(n.acc_id)
            }) : a.index.navigateTo({
              url: "/pages/author/author?acc_id=".concat(n.acc_id, "&code=").concat(o.data.code, "&alb_id=").concat(e.show_res_id, "&page_path=album")
            })
          } else t.searchValue = "", a.index.showModal({
            title: "温馨提示",
            content: "暂无相关创作者，请换个口令搜索吧~",
            showCancel: !1,
            confirmColor: "#e6645f"
          })
        }))
      },
      showShareData: function() {
        var o = JSON.stringify({
          acc_id: t.globalData.acc_id,
          alb_id: t.globalData.alb_id,
          res_id: t.globalData.res_id,
          openid: t.globalData.openid,
          code: t.globalData.code,
          ver: t.globalData.ver
        });
        a.index.setClipboardData({
          data: o,
          success: function(t) {
            a.index.showModal({
              title: "提示",
              content: "option:".concat(o)
            })
          }
        })
      },
      goCreater: function() {
        a.index.navigateTo({
          url: "/pages/creater/creater"
        })
      }
    }
  };
Array || (a.resolveComponent("advert") + a.resolveComponent("complain"))();
var n = a._export_sfc(o, [
  ["render", function(t, o, n, e, i, c) {
    return a.e({
      a: a.o((function() {
        return c.goCreater && c.goCreater.apply(c, arguments)
      })),
      b: a.o((function(a) {
        return i.showAdvert = !0
      })),
      c: i.inputFocus,
      d: a.o((function() {
        return c.bindSearch && c.bindSearch.apply(c, arguments)
      })),
      e: i.searchValue,
      f: a.o((function(a) {
        return i.searchValue = a.detail.value
      })),
      g: a.o((function() {
        return c.bindSearch && c.bindSearch.apply(c, arguments)
      })),
      h: i.recommendList.length > 0
    }, i.recommendList.length > 0 ? {
      i: a.o((function() {
        return c.showShareData && c.showShareData.apply(c, arguments)
      })),
      j: a.f(i.recommendList, (function(t, o, n) {
        return {
          a: t.app_head_img,
          b: o,
          c: a.o((function(a) {
            return c.bindAuthor(t)
          }), o)
        }
      }))
    } : {}, {
      k: i.listData.length > 0
    }, i.listData.length > 0 ? {
      l: a.f(i.listData, (function(o, n, e) {
        return {
          a: t.$link(o.img),
          b: n,
          c: a.o((function(a) {
            return c.bindImage(o)
          }), n)
        }
      }))
    } : {}, {
      m: a.o((function(a) {
        return i.showAdvert = !1
      })),
      n: a.p({
        showAdvert: i.showAdvert
      })
    })
  }]
]);
wx.createPage(n);