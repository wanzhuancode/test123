require("../../@babel/runtime/helpers/Objectvalues");
var t = require("../../common/vendor.js"),
  e = getApp(),
  n = {
    name: "resource-list-date",
    components: {
      myImage: function() {
        return "../../components/my-image.js"
      },
      empty: function() {
        return "../../components/empty.js"
      }
    },
    props: {
      acc_id: {
        type: [Number, String],
        default: ""
      },
      type: {
        type: [Number, String],
        default: ""
      },
      sort: {
        type: [Number, String],
        default: ""
      },
      page: {
        type: [Number, String],
        default: ""
      }
    },
    data: function() {
      return {
        pageIndex: 1,
        dateList: {},
        loadStatus: "more"
      }
    },
    watch: {
      type: function() {
        this.initPage()
      },
      page: function(t) {
        1 == t && 0 == this.imageList.length && this.getPageData()
      }
    },
    created: function() {
      var t = this;
      1 == this.page && this.$nextTick((function() {
        t.getPageData()
      }))
    },
    methods: {
      initPage: function() {
        this.pageIndex = 1, this.dateList = {}, this.loadStatus = "loading", this.getPageData()
      },
      getPageData: function() {
        var e = this;
        t.index.showLoading({
          title: "资源加载中..."
        }), this.$api.pageIndex({
          data: {
            acc_id: this.acc_id,
            page: this.pageIndex,
            class: this.type,
            sort: this.sort
          }
        }).then((function(n) {
          var a;
          if (e.initDateList(n.data.list), t.index.hideLoading(), 0 === (null == (a = n.data.list) ? void 0 : a.length)) return e.loadStatus = "no-more", t.index.showToast({
            title: "暂无更多资源",
            icon: "none"
          }), !1;
          e.loadStatus = "more"
        })).catch((function(n) {
          e.loadStatus = "no-more", t.index.hideLoading()
        }))
      },
      initDateList: function(t) {
        var e = this;
        (null == t ? void 0 : t.length) > 0 && t.forEach((function(t) {
          e.dateList[t.date] ? e.dateList[t.date].push(t) : e.dateList[t.date] = [t]
        }))
      },
      initDateKey: function(t) {
        var e = t.split("-");
        return "".concat(e[0], "年").concat(e[1], "月").concat(e[2], "日")
      },
      getMoreData: function() {
        console.log(this.loadStatus), "more" == this.loadStatus && (this.loadStatus = "loading", this.pageIndex++, this.getPageData())
      },
      binSelect: function(n) {
        var a = this.dateList[n.date].filter((function(t) {
            return t.class === n.class
          })),
          i = a.findIndex((function(t) {
            return n.res_id === t.res_id
          })),
          o = Math.floor(i / 30),
          c = a.slice(30 * o, 30 * (o + 1)),
          r = "/pages/preview/preview?image=" + encodeURIComponent(JSON.stringify(n));
        2 == n.class && (e.globalData.userData = this.userData, c = c.filter((function(t) {
          return 2 == t.class || 3 == t.class
        })), r = "/pages/preview/avatar?image=" + encodeURIComponent(JSON.stringify(n))), e.globalData.imageList = c, t.index.navigateTo({
          url: "".concat(r)
        })
      }
    }
  };
Array || (t.resolveComponent("my-image") + t.resolveComponent("empty"))();
var a = t._export_sfc(n, [
  ["render", function(e, n, a, i, o, c) {
    return t.e({
      a: Object.values(o.dateList).length > 0 || "loading" === o.loadStatus
    }, Object.values(o.dateList).length > 0 || "loading" === o.loadStatus ? {
      b: t.f(o.dateList, (function(e, n, i) {
        return t.e({
          a: t.t(c.initDateKey(n))
        }, 2 === a.type || 3 === a.type ? {
          b: t.f(e, (function(e, n, a) {
            return t.e({
              a: n % 4 == 0
            }, n % 4 == 0 ? {
              b: n,
              c: t.o((function(t) {
                return c.binSelect(e)
              }), n),
              d: "87c91caa-0-" + i + "-" + a,
              e: t.p({
                img: e,
                col: "4"
              })
            } : {})
          })),
          c: t.f(e, (function(e, n, a) {
            return t.e({
              a: n % 4 == 1
            }, n % 4 == 1 ? {
              b: n,
              c: t.o((function(t) {
                return c.binSelect(e)
              }), n),
              d: "87c91caa-1-" + i + "-" + a,
              e: t.p({
                img: e,
                col: "4"
              })
            } : {})
          })),
          d: t.f(e, (function(e, n, a) {
            return t.e({
              a: n % 4 == 2
            }, n % 4 == 2 ? {
              b: n,
              c: t.o((function(t) {
                return c.binSelect(e)
              }), n),
              d: "87c91caa-2-" + i + "-" + a,
              e: t.p({
                img: e,
                col: "4"
              })
            } : {})
          })),
          e: t.f(e, (function(e, n, a) {
            return t.e({
              a: n % 4 == 3
            }, n % 4 == 3 ? {
              b: n,
              c: t.o((function(t) {
                return c.binSelect(e)
              }), n),
              d: "87c91caa-3-" + i + "-" + a,
              e: t.p({
                img: e,
                col: "4"
              })
            } : {})
          }))
        } : {
          f: t.f(e, (function(e, n, a) {
            return t.e({
              a: n % 3 == 0
            }, n % 3 == 0 ? {
              b: n,
              c: t.o((function(t) {
                return c.binSelect(e)
              }), n),
              d: "87c91caa-4-" + i + "-" + a,
              e: t.p({
                img: e
              })
            } : {})
          })),
          g: t.f(e, (function(e, n, a) {
            return t.e({
              a: n % 3 == 1
            }, n % 3 == 1 ? {
              b: n,
              c: t.o((function(t) {
                return c.binSelect(e)
              }), n),
              d: "87c91caa-5-" + i + "-" + a,
              e: t.p({
                img: e
              })
            } : {})
          })),
          h: t.f(e, (function(e, n, a) {
            return t.e({
              a: n % 3 == 2
            }, n % 3 == 2 ? {
              b: n,
              c: t.o((function(t) {
                return c.binSelect(e)
              }), n),
              d: "87c91caa-6-" + i + "-" + a,
              e: t.p({
                img: e
              })
            } : {})
          }))
        }, {
          i: n
        })
      })),
      c: 2 === a.type || 3 === a.type
    } : {
      d: t.p({
        text: "资源空空如也~"
      })
    })
  }],
  ["__scopeId", "data-v-87c91caa"]
]);
wx.createComponent(a);