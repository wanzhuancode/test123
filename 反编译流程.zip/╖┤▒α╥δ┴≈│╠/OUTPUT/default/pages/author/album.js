var t = require("../../@babel/runtime/helpers/toConsumableArray"),
  e = require("../../common/vendor.js");
getApp();
var a = {
  props: {
    acc_id: {
      type: [String, Number],
      default: ""
    },
    page: {
      type: [String, Number],
      default: ""
    }
  },
  components: {
    empty: function() {
      return "../../components/empty.js"
    }
  },
  data: function() {
    return {
      albumList: [],
      pageIndex: 1,
      loadStatus: "more"
    }
  },
  watch: {
    page: function(t) {
      2 == t && 0 == this.albumList.length && this.getAlbumList()
    }
  },
  created: function() {
    var t = this;
    2 == this.page && this.$nextTick((function() {
      t.getAlbumList()
    }))
  },
  methods: {
    getAlbumList: function() {
      var a = this;
      e.index.showLoading({
        title: "加载中..."
      }), this.$api.albumList({
        data: {
          acc_id: this.acc_id,
          page: this.pageIndex
        }
      }).then((function(i) {
        var n;
        console.log(i), e.index.hideLoading(), 0 == (null == (n = i.data.list) ? void 0 : n.length) ? (a.loadStatus = "no-more", e.index.showToast({
          title: "暂无更多资源",
          icon: "none"
        })) : a.loadStatus = "more", a.albumList = [].concat(t(a.albumList), t(i.data.list))
      })).catch((function(t) {
        e.index.hideLoading(), a.loadStatus = "no-more"
      }))
    },
    selectAlbum: function(t) {
      return e.index.navigateTo({
        url: "/pages/album/album?acc_id=".concat(this.acc_id, "&alb_id=").concat(t.alb_id)
      })
    },
    getMoreData: function() {
      "more" == this.loadStatus && (this.loadStatus = "loading", this.pageIndex++, this.getAlbumList())
    }
  }
};
Array || e.resolveComponent("empty")();
var i = e._export_sfc(a, [
  ["render", function(t, a, i, n, o, s) {
    return e.e({
      a: o.albumList.length > 0
    }, o.albumList.length > 0 ? {
      b: e.f(o.albumList, (function(a, i, n) {
        return e.e({
          a: a.cover.list.length > 0
        }, a.cover.list.length > 0 ? e.e({
          b: a.is_top > 0
        }, (a.is_top, {}), {
          c: e.t(a.name),
          d: e.f(a.cover.list, (function(i, n, o) {
            return e.e({
              a: t.$link(i.img),
              b: 3 === n && a.cover.sum > 4
            }, 3 === n && a.cover.sum > 4 ? {
              c: e.t(a.cover.sum - 4)
            } : {}, {
              d: n
            })
          })),
          e: e.o((function(t) {
            return s.selectAlbum(a)
          }), a.alb_id)
        }) : {}, {
          f: a.alb_id
        })
      }))
    } : {
      c: e.p({
        title: "专辑空空如也~",
        "empty-style": "margin-top: 150rpx;"
      })
    })
  }],
  ["__scopeId", "data-v-a58c7a44"]
]);
wx.createComponent(i);