require("../../@babel/runtime/helpers/Arrayincludes");
var a = require("../../common/vendor.js"),
  t = require("../../utils/js/common.js"),
  e = getApp(),
  o = {
    components: {
      navback: function() {
        return "../../components/navBack.js"
      },
      album: function() {
        return "./album.js"
      },
      resourceList: function() {
        return "./resourceList.js"
      },
      resourceListDate: function() {
        return "./resourceListDate.js"
      }
    },
    data: function() {
      return {
        userData: null,
        loadTime: null,
        page: 1,
        sort: 1,
        type: 0,
        catList: [],
        scrollTop: 0,
        lastScrollTop: 0,
        code: ""
      }
    },
    onLoad: function(t) {
      t.acc_id || t.code ? this.getSearchData(t) : a.index.redirectTo({
        url: "/pages/index/index"
      })
    },
    onShareAppMessage: function(a) {
      var o = "原图";
      1 == this.page && (o = t.getShareData(this.type));
      var r = e.globalData.code,
        c = "/pages/author/author?acc_id=".concat(this.userData.acc_id, "&code=").concat(r, "&page=").concat(this.page, "&show_type=").concat(this.type);
      return {
        channel: a.channel,
        imageUrl: !1,
        title: "点击下载同款" + o,
        path: c,
        extra: {
          withVideoId: !0
        },
        success: function(a) {}
      }
    },
    methods: {
      getSearchData: function(t) {
        var o = this;
        this.$api.accountData({
          data: {
            code: t.code,
            acc_id: t.acc_id
          }
        }).then((function(r) {
          if (console.log("code_data", r.data), !r.data) return a.index.redirectTo({
            url: "/pages/index/index"
          });
          e.globalData.accData = r.data.acc_data, e.globalData.code = r.data.code, e.globalData.acc_id = r.data.acc_data.acc_id, o.userData = r.data.acc_data, o.catList = r.data.acc_class_list, o.code = r.data.code, 1 == r.data.show_data.show_class && (o.type = t.show_type ? t.show_type : r.data.show_data.show_res_id, o.page = t.page ? t.page : 1, o.page > 2 && (o.page = 1), o.type > 5 && (o.type = 0)), 2 == r.data.show_data.show_class && (o.page = t.page ? t.page : 2, o.page > 2 && (o.page = 2), "album" == t.page_path && (o.page = 2), 1 == o.page && (o.type = t.show_type ? t.show_type : 0, o.type > 5 && (o.type = 0))), 3 == r.data.show_data.show_class && (o.type = t.show_type ? t.show_type : 0, o.page = 2, o.type > 5 && (o.type = 0)), o.sort = t.sort ? t.sort : r.data.acc_data.def_sort, t.page_path && o.toSharePage(t)
        }))
      },
      toSharePage: function(t) {
        var o = "";
        switch (t.page_path) {
          case "preview":
            o = "/pages/preview/preview";
            break;
          case "avatar":
            o = "/pages/preview/avatar";
            break;
          case "album":
            o = "/pages/album/album"
        }
        for (var r in t) e.globalData[r] = t[r], ["acc_id", "code", "alb_id", "page_path", "res_id"].includes(r) && (o += "&".concat(r, "=").concat(t[r]));
        setTimeout((function() {
          a.index.navigateTo({
            url: o.replace("&", "?")
          })
        }), 500)
      },
      switchPage: function(a) {
        this.page = a
      },
      bindeType: function(a) {
        this.type = a.class
      },
      getMoreData: function() {
        1 == this.page ? this.$refs.resource.getMoreData() : this.$refs.album.getMoreData()
      },
      bindScroll: function(a) {
        this.lastScrollTop = a.detail.scrollTop
      },
      scrollToTop: function() {
        var a = this;
        this.scrollTop = this.lastScrollTop, this.$nextTick((function() {
          a.scrollTop = 0
        }))
      },
      bindSort: function(a) {
        this.sort = a
      },
      bindStatement: function() {
        a.index.showModal({
          title: "声明",
          content: "所有素材均由创作者上传及负责，部分素材来源网络，如有侵权，请联系我们进行删除处理",
          showCancel: !1
        })
      }
    }
  };
Array || (a.resolveComponent("navback") + a.resolveComponent("resource-list-date") + a.resolveComponent("resource-list") + a.resolveComponent("album"))();
var r = a._export_sfc(o, [
  ["render", function(t, e, o, r, c, s) {
    return a.e({
      a: c.userData
    }, c.userData ? a.e({
      b: c.userData.app_head_img,
      c: a.t(c.userData.app_name),
      d: a.t(c.code),
      e: a.o((function() {
        return s.bindStatement && s.bindStatement.apply(s, arguments)
      })),
      f: 1 == c.page
    }, 1 == c.page ? a.e({
      g: 1 == c.sort
    }, (c.sort, {}), {
      h: 1 == c.sort ? 1 : "",
      i: a.o((function(a) {
        return s.bindSort(1)
      })),
      j: 2 == c.sort
    }, (c.sort, {}), {
      k: 2 == c.sort ? 1 : "",
      l: a.o((function(a) {
        return s.bindSort(2)
      }))
    }) : {}) : {}, {
      m: c.userData
    }, c.userData ? a.e({
      n: a.t(c.userData.res_num),
      o: 1 == c.page ? 1 : "",
      p: a.o((function(a) {
        return s.switchPage(1)
      })),
      q: a.t(c.userData.alb_num),
      r: 2 == c.page ? 1 : "",
      s: a.o((function(a) {
        return s.switchPage(2)
      })),
      t: c.catList.length >= 2
    }, c.catList.length >= 2 ? {
      v: a.f(c.catList, (function(t, e, o) {
        return {
          a: a.t(t.title),
          b: e,
          c: t.class == c.type ? 1 : "",
          d: a.o((function(a) {
            return s.bindeType(t)
          }), e)
        }
      }))
    } : {}, {
      w: 2 == c.sort
    }, 2 == c.sort ? {
      x: a.sr("resource", "95ce8d30-1"),
      y: a.p({
        page: c.page,
        acc_id: c.userData.acc_id,
        type: c.type,
        sort: c.sort
      })
    } : {
      z: a.sr("resource", "95ce8d30-2"),
      A: a.p({
        page: c.page,
        acc_id: c.userData.acc_id,
        type: c.type,
        sort: c.sort
      })
    }, {
      B: 1 == c.page,
      C: a.sr("album", "95ce8d30-3"),
      D: 2 == c.page,
      E: a.p({
        page: c.page,
        acc_id: c.userData.acc_id
      })
    }) : {}, {
      F: c.scrollTop,
      G: a.o((function() {
        return s.getMoreData && s.getMoreData.apply(s, arguments)
      })),
      H: a.o((function() {
        return s.bindScroll && s.bindScroll.apply(s, arguments)
      })),
      I: c.lastScrollTop > 500,
      J: a.o((function() {
        return s.scrollToTop && s.scrollToTop.apply(s, arguments)
      }))
    })
  }],
  ["__scopeId", "data-v-95ce8d30"]
]);
o.__runtimeHooks = 2, wx.createPage(r);