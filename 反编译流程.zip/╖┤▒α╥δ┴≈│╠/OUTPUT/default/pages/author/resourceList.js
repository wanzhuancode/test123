var e = require("../../@babel/runtime/helpers/toConsumableArray"),
  t = require("../../common/vendor.js"),
  i = getApp(),
  n = {
    name: "resource-list",
    components: {
      myImage: function() {
        return "../../components/my-image.js"
      },
      empty: function() {
        return "../../components/empty.js"
      }
    },
    props: {
      acc_id: {
        type: [Number, String],
        default: ""
      },
      type: {
        type: [Number, String],
        default: ""
      },
      sort: {
        type: [Number, String],
        default: ""
      },
      page: {
        type: [Number, String],
        default: ""
      }
    },
    data: function() {
      return {
        pageIndex: 1,
        loadTime: null,
        imageList: [],
        loadStatus: "loading"
      }
    },
    watch: {
      type: function(e) {
        console.log(e), this.initPage()
      },
      sort: function() {
        this.initPage()
      },
      page: function(e) {
        1 == e && 0 == this.imageList.length && this.getPageData()
      }
    },
    created: function() {
      var e = this;
      1 == this.page && this.$nextTick((function() {
        e.getPageData()
      }))
    },
    methods: {
      initPage: function() {
        this.pageIndex = 1, this.imageList = [], this.loadStatus = "loading", this.getPageData()
      },
      getPageData: function() {
        var i = this;
        t.index.showLoading({
          title: "资源加载中..."
        }), this.$api.pageIndex({
          data: {
            acc_id: this.acc_id,
            page: this.pageIndex,
            class: this.type,
            sort: this.sort
          }
        }).then((function(n) {
          var a;
          i.imageList = [].concat(e(i.imageList), e(n.data.list)), console.log("this.imageList", i.imageList), 0 == (null == (a = n.data.list) ? void 0 : a.length) ? (i.loadStatus = "no-more", t.index.hideLoading(), t.index.showToast({
            title: "暂无更多资源",
            icon: "none",
            duration: 2e3
          })) : (t.index.hideLoading(), i.loadStatus = "more")
        })).catch((function(e) {
          t.index.hideLoading(), i.loadStatus = "no-more"
        }))
      },
      getMoreData: function() {
        var e = this;
        "more" == this.loadStatus && (this.loadStatus = "loading", this.loadTime && clearTimeout(this.loadTime), this.loadTime = setTimeout((function() {
          e.pageIndex++, e.getPageData()
        })))
      },
      binSelect: function(e) {
        var n = this.imageList.filter((function(t) {
            return t.class === e.class
          })),
          a = n.findIndex((function(t) {
            return e.res_id === t.res_id
          })),
          o = Math.floor(a / 30),
          r = n.slice(30 * o, 30 * (o + 1)),
          s = "/pages/preview/preview?image=" + encodeURIComponent(JSON.stringify(e));
        2 == e.class && (i.globalData.userData = this.userData, s = "/pages/preview/avatar?image=" + encodeURIComponent(JSON.stringify(e))), i.globalData.imageList = r, t.index.navigateTo({
          url: "".concat(s)
        })
      }
    }
  };
Array || (t.resolveComponent("my-image") + t.resolveComponent("empty"))();
var a = t._export_sfc(n, [
  ["render", function(e, i, n, a, o, r) {
    return t.e({
      a: o.imageList.length > 0 || "loading" === o.loadStatus
    }, o.imageList.length > 0 || "loading" === o.loadStatus ? t.e({
      b: 2 === n.type || 3 === n.type
    }, 2 === n.type || 3 === n.type ? {
      c: t.f(o.imageList, (function(e, i, n) {
        return t.e({
          a: i % 4 == 0
        }, i % 4 == 0 ? {
          b: i,
          c: t.o((function(t) {
            return r.binSelect(e)
          }), i),
          d: "7add90be-0-" + n,
          e: t.p({
            img: e,
            col: "4"
          })
        } : {})
      })),
      d: t.f(o.imageList, (function(e, i, n) {
        return t.e({
          a: i % 4 == 1
        }, i % 4 == 1 ? {
          b: i,
          c: t.o((function(t) {
            return r.binSelect(e)
          }), i),
          d: "7add90be-1-" + n,
          e: t.p({
            img: e,
            col: "4"
          })
        } : {})
      })),
      e: t.f(o.imageList, (function(e, i, n) {
        return t.e({
          a: i % 4 == 2
        }, i % 4 == 2 ? {
          b: i,
          c: t.o((function(t) {
            return r.binSelect(e)
          }), i),
          d: "7add90be-2-" + n,
          e: t.p({
            img: e,
            col: "4"
          })
        } : {})
      })),
      f: t.f(o.imageList, (function(e, i, n) {
        return t.e({
          a: i % 4 == 3
        }, i % 4 == 3 ? {
          b: i,
          c: t.o((function(t) {
            return r.binSelect(e)
          }), i),
          d: "7add90be-3-" + n,
          e: t.p({
            img: e,
            col: "4"
          })
        } : {})
      }))
    } : {
      g: t.f(o.imageList, (function(e, i, n) {
        return t.e({
          a: i % 3 == 0
        }, i % 3 == 0 ? {
          b: i,
          c: t.o((function(t) {
            return r.binSelect(e)
          }), i),
          d: "7add90be-4-" + n,
          e: t.p({
            img: e
          })
        } : {})
      })),
      h: t.f(o.imageList, (function(e, i, n) {
        return t.e({
          a: i % 3 == 1
        }, i % 3 == 1 ? {
          b: i,
          c: t.o((function(t) {
            return r.binSelect(e)
          }), i),
          d: "7add90be-5-" + n,
          e: t.p({
            img: e
          })
        } : {})
      })),
      i: t.f(o.imageList, (function(e, i, n) {
        return t.e({
          a: i % 3 == 2
        }, i % 3 == 2 ? {
          b: i,
          c: t.o((function(t) {
            return r.binSelect(e)
          }), i),
          d: "7add90be-6-" + n,
          e: t.p({
            img: e
          })
        } : {})
      }))
    }) : {
      j: t.p({
        text: "资源空空如也~"
      })
    })
  }],
  ["__scopeId", "data-v-7add90be"]
]);
wx.createComponent(a);