var n = require("../../common/vendor.js");
Array || n.resolveComponent("navBack")();
var r = n._export_sfc({
  components: {
    navBack: function() {
      return "../../components/navBack.js"
    }
  },
  data: function() {
    return {}
  }
}, [
  ["render", function(n, r, e, o, t, a) {
    return {}
  }]
]);
wx.createPage(r);