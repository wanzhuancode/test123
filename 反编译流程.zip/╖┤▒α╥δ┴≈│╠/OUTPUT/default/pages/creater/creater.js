var e = require("../../common/vendor.js"),
  n = require("../../utils/js/common.js");
getApp();
var t = {
  data: function() {
    return {
      creater_data: "",
      downloadTime: null,
      downloading: !1,
      editFrom: {
        phone: "",
        content: ""
      }
    }
  },
  components: {
    navback: function() {
      return "../../components/navBack.js"
    }
  },
  onLoad: function(e) {
    var n = this;
    this.$api.promotion().then((function(e) {
      console.log(e), n.creater_data = e.page_data
    }))
  },
  methods: {
    saveQrcode: function() {
      e.index.showLoading({
        title: "下载中..."
      }), n.downloadFile(this.creater_data.kf).then((function() {
        e.index.hideLoading(), e.index.showToast({
          title: "保存成功！"
        })
      })).catch((function(n) {
        e.index.hideLoading(), e.index.showToast({
          title: "下载失败！",
          icon: "none"
        })
      }))
    }
  }
};
Array || e.resolveComponent("navback")();
var a = e._export_sfc(t, [
  ["render", function(n, t, a, o, r, c) {
    return e.e({
      a: r.creater_data
    }, r.creater_data ? e.e({
      b: r.creater_data.kf
    }, r.creater_data.kf ? {
      c: r.creater_data.kf,
      d: e.o((function() {
        return c.saveQrcode && c.saveQrcode.apply(c, arguments)
      }))
    } : {}) : {})
  }]
]);
wx.createPage(a);