var n = require("../../common/vendor.js");
getApp();
var e = {
  data: function() {
    return {
      moreData: null,
      banner: "http://min-cdn.xliii.cn/miniapp/juejinbizhi/ts_new/creater/banner.png",
      navTop: n.index.getSystemInfoSync().statusBarHeight + "px",
      jumping: !1,
      config: {}
    }
  },
  components: {
    complain: function() {
      return "../../components/complain.js"
    },
    empty: function() {
      return "../../components/empty.js"
    }
  },
  onLoad: function() {
    this.popData()
  },
  methods: {
    popData: function() {
      var e = this;
      n.index.showLoading({
        title: "加载中..."
      }), this.$api.recommend().then((function(t) {
        console.log(t), e.moreData = t.data, n.index.hideLoading()
      }))
    },
    goCreater: function() {
      n.index.navigateTo({
        url: "/pages/creater/creater"
      })
    },
    toAuthor: function(e) {
      n.index.navigateTo({
        url: "/pages/author/author?acc_id=" + e.acc_id
      })
    }
  }
};
Array || (n.resolveComponent("empty") + n.resolveComponent("complain"))();
var t = n._export_sfc(e, [
  ["render", function(e, t, o, a, r, i) {
    return n.e({
      a: n.o((function() {
        return i.goCreater && i.goCreater.apply(i, arguments)
      })),
      b: r.banner,
      c: r.moreData
    }, r.moreData ? {
      d: n.f(r.moreData, (function(t, o, a) {
        return n.e({
          a: t.app_head_img,
          b: n.t(t.app_name),
          c: n.t(t.res_num),
          d: n.o((function(n) {
            return i.toAuthor(t)
          }), o),
          e: n.f(t.show_img.list.slice(0, 3), (function(o, a, r) {
            return {
              a: n.o((function(n) {
                return i.toAuthor(t)
              }), a),
              b: e.$link(o.img),
              c: a
            }
          })),
          f: 0 == t.show_img.list.length
        }, 0 == t.show_img.list.length ? {
          g: "38c3fb69-0-" + a
        } : {}, {
          h: o
        })
      }))
    } : {}, {
      e: r.navTop
    })
  }],
  ["__scopeId", "data-v-38c3fb69"]
]);
wx.createPage(t);