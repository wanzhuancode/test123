var e = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  t = require("../../@babel/runtime/helpers/asyncToGenerator"),
  o = require("../../common/vendor.js"),
  a = require("../../utils/js/pay.js"),
  r = getApp(),
  n = {
    data: function() {
      return {
        good_id: 3,
        vip: 0,
        orderType: 0,
        gid: 0,
        res_type: 1,
        userData: {},
        userList: [],
        goodsData: [],
        activity: r.globalData.activity,
        SDKVersion: tt.getSystemInfoSync().SDKVersion
      }
    },
    components: {
      navBack: function() {
        return "../../components/navBack.js"
      },
      maoScroll: function() {
        return "../../components/mao-scroll/mao-scroll.js"
      },
      popup: function() {
        return "../../components/popup.js"
      }
    },
    computed: {
      payIndex: function() {
        var e = this;
        return this.goodsData.findIndex((function(t) {
          return t.good_id == e.good_id
        }))
      },
      payMoney: function() {
        return (this.goodsData[this.payIndex] || {}).money || 0
      }
    },
    onLoad: function(o) {
      var a = this;
      return t(e().mark((function t() {
        var n;
        return e().wrap((function(e) {
          for (;;) switch (e.prev = e.next) {
            case 0:
              a.gid = o.gid || 0, a.res_type = o.res_type || 1, a.activity = r.globalData.activity, 2 != r.globalData.activity && (r.globalData.activity = 1, a.good_id = 3), a.userList = (null == (n = a.userCommonList) ? void 0 : n.slice(0, 40)) || [], a.getGoodsList();
            case 1:
            case "end":
              return e.stop()
          }
        }), t)
      })))()
    },
    methods: {
      getGoodsList: function() {
        var e = this;
        this.$api.goodsList({
          data: {
            sopenid: getApp().globalData.code,
            res_type: this.res_type,
            res_id: this.gid
          }
        }).then((function(t) {
          console.log(t), t.good_list && (e.goodsData = t.good_list), e.appUserData()
        }))
      },
      appUserData: function() {
        var e = this;
        this.$api.appUserData().then((function(t) {
          console.log(t), 1 === t.status && (e.vip = t.vip, e.userData = t, e.vip > 0 && (r.globalData.activity = 0, e.good_id = e.vip)), 2 == r.globalData.activity && (e.good_id = 1)
        }))
      },
      filterName: function(e) {
        return console.log(e), e
      },
      getOrder: function() {
        var e = this;
        a.payMixin({
          sopenid: r.globalData.code,
          res_type: 1,
          res_id: this.gid,
          good_id: this.good_id
        }, (function(t, o) {
          e.orderType = t, e.order_id = o
        }))
      },
      queryOrder: function() {
        var e = this;
        a.queryOrder(this.order_id, (function(t) {
          e.orderType = orderType
        }))
      },
      checkProtocol: function() {
        o.index.navigateTo({
          url: "/pages/agreement/agreement"
        })
      },
      protocol: function() {
        o.index.navigateTo({
          url: "/pages/advert/advert"
        })
      },
      bindBack: function() {
        this.orderType = 0, r.globalData.activity = 0, o.index.navigateBack()
      }
    }
  };
Array || (o.resolveComponent("navBack") + o.resolveComponent("maoScroll") + o.resolveComponent("template") + o.resolveComponent("popup"))();
var i = o._export_sfc(n, [
  ["render", function(e, t, a, r, n, i) {
    var s;
    return o.e({
      a: n.userData.vip > 0
    }, (n.userData.vip, {}), {
      b: n.userData.head
    }, n.userData.head ? {
      c: n.userData.head
    } : {}, {
      d: n.userData.nickname
    }, n.userData.nickname ? {
      e: o.t(n.userData.nickname)
    } : {}, {
      f: n.userData.vip > 0
    }, (n.userData.vip, {}), {
      g: n.userData.end_date
    }, n.userData.end_date ? {
      h: o.t(n.userData.end_date)
    } : {}, {
      i: o.f(n.goodsData, (function(e, t, a) {
        return o.e({
          a: 1 == e.good_id && 2 == n.activity || 1 != e.good_id
        }, 1 == e.good_id && 2 == n.activity || 1 != e.good_id ? {
          b: o.t(e.goods_arr.tip_1),
          c: o.t(e.title),
          d: o.t(e.goods_arr.tip_2),
          e: o.t(e.show_money),
          f: o.t(e.goods_arr.tip_3),
          g: o.t(e.goods_arr.tip_4),
          h: i.payIndex == t ? 1 : "",
          i: o.o((function(t) {
            return n.good_id = e.good_id
          }), t)
        } : {}, {
          j: t
        })
      })),
      j: o.t((null == (s = n.goodsData[i.payIndex]) ? void 0 : s.desc) || ""),
      k: n.userList.length > 0
    }, n.userList.length > 0 ? {
      l: o.p({
        data: n.userList
      })
    } : {}, {
      m: o.o((function() {
        return i.protocol && i.protocol.apply(i, arguments)
      })),
      n: n.SDKVersion >= "3.1.0" ? "byteHi" : "contact",
      o: o.t(n.goodsData[i.payIndex] ? n.goodsData[i.payIndex].title : ""),
      p: o.t(n.goodsData[i.payIndex] ? n.goodsData[i.payIndex].show_money : 0),
      q: o.o((function() {
        return i.getOrder && i.getOrder.apply(i, arguments)
      })),
      r: 1 == n.orderType
    }, 1 == n.orderType ? {
      s: o.o((function() {
        return i.bindBack && i.bindBack.apply(i, arguments)
      }))
    } : {
      t: o.o((function() {
        return i.queryOrder && i.queryOrder.apply(i, arguments)
      }))
    }, {
      v: o.o((function(e) {
        return n.orderType = 0
      })),
      w: o.n(1 == n.orderType ? "success" : "fail"),
      x: o.o((function(e) {
        return n.orderType = 0
      })),
      y: o.p({
        show: 0 != n.orderType
      })
    })
  }],
  ["__scopeId", "data-v-eed62890"]
]);
wx.createPage(i);