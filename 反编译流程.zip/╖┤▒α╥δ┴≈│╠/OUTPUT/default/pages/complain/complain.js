var n = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  e = require("../../@babel/runtime/helpers/asyncToGenerator"),
  t = require("../../@babel/runtime/helpers/toConsumableArray"),
  i = require("../../common/vendor.js"),
  o = require("../../utils/js/common.js"),
  r = {
    data: function() {
      return {
        loading: !1,
        imageList: [],
        content: "",
        phone: ""
      }
    },
    components: {
      navBack: function() {
        return "../../components/navBack.js"
      }
    },
    methods: {
      bindTextAreaBlur: function(n) {
        this.content = n.detail.value
      },
      bindInput: function(n) {
        this.phone = n.detail.value
      },
      jumpQuestion: function() {
        i.index.navigateTo({
          url: "/pages/complain/question"
        })
      },
      chooseImage: function() {
        var n = this;
        if (this.loading) return i.index.showToast({
          title: "请稍后再次提交！"
        });
        this.loading = !0, o.chooseImage(4 - this.imageList.length).then((function(e) {
          n.imageList = [].concat(t(n.imageList), t(e))
        })).finally((function(e) {
          n.loading = !1
        }))
      },
      delImage: function(n) {
        this.imageList.splice(n, 1)
      },
      confirmForm: function() {
        var t = this;
        return e(n().mark((function e() {
          var o;
          return n().wrap((function(n) {
            for (;;) switch (n.prev = n.next) {
              case 0:
                if (o = "", t.content || (o = "吐槽内容不能为空!"), !o) {
                  n.next = 3;
                  break
                }
                return n.abrupt("return", i.index.showToast({
                  title: o,
                  icon: "none"
                }));
              case 3:
                t.$api.freeBack({
                  data: {
                    phone: t.phone,
                    content: t.content,
                    img: JSON.stringify(t.imageList),
                    type: 0
                  }
                }).then((function() {
                  i.index.showModal({
                    content: "提交成功,感谢您的反馈！",
                    showCancel: !1,
                    success: function(n) {
                      t.phone = "", t.content = "", t.imageList = []
                    }
                  })
                })).catch((function() {
                  i.index.showToast({
                    title: "提交失败",
                    icon: "fail"
                  })
                }));
              case 4:
              case "end":
                return n.stop()
            }
          }), e)
        })))()
      }
    }
  };
Array || i.resolveComponent("navBack")();
var a = i._export_sfc(r, [
  ["render", function(n, e, t, o, r, a) {
    return i.e({
      a: i.o((function() {
        return a.jumpQuestion && a.jumpQuestion.apply(a, arguments)
      })),
      b: r.content,
      c: i.o((function() {
        return a.bindTextAreaBlur && a.bindTextAreaBlur.apply(a, arguments)
      })),
      d: i.t(r.content.length),
      e: i.t(r.imageList.length),
      f: i.f(r.imageList, (function(n, e, t) {
        return {
          a: n,
          b: i.o((function(n) {
            return a.delImage(e)
          }), e),
          c: e
        }
      })),
      g: r.imageList.length < 4
    }, r.imageList.length < 4 ? {
      h: i.o((function() {
        return a.chooseImage && a.chooseImage.apply(a, arguments)
      }))
    } : {}, {
      i: r.phone,
      j: i.o((function() {
        return a.bindInput && a.bindInput.apply(a, arguments)
      })),
      k: i.o((function() {
        return a.confirmForm && a.confirmForm.apply(a, arguments)
      }))
    })
  }],
  ["__scopeId", "data-v-39ccbd4d"]
]);
wx.createPage(a);