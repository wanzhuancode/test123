var e = require("../../@babel/runtime/helpers/toConsumableArray"),
  t = require("../../@babel/runtime/helpers/regeneratorRuntime"),
  r = require("../../@babel/runtime/helpers/asyncToGenerator"),
  n = require("../../common/vendor.js"),
  a = require("../../utils/js/common.js"),
  o = getApp(),
  s = {
    components: {
      navBack: function() {
        return "../../components/navBack.js"
      }
    },
    data: function() {
      return {
        userData: {},
        userInfo: null,
        appid_uid: 0,
        vip: 0,
        pay_status: 0,
        pageIndex: 0,
        orderList: [],
        noMore: !1,
        quitAcc: !1
      }
    },
    onLoad: function() {
      var e = this;
      return r(t().mark((function r() {
        return t().wrap((function(t) {
          for (;;) switch (t.prev = t.next) {
            case 0:
              e.getUserData(), e.getOrderList();
            case 1:
            case "end":
              return t.stop()
          }
        }), r)
      })))()
    },
    methods: {
      getUserData: function() {
        var e = this;
        this.$api.appUserData().then((function(t) {
          e.userInfo = a.getStorage("userInfo") || null, e.userData = t, e.vip = t.vip
        }))
      },
      getOrderList: function() {
        var t = this;
        this.noMore || (this.pageIndex++, this.$api.getUserOrderList({
          data: {
            pay_type: 1,
            page: this.pageIndex
          }
        }).then((function(r) {
          console.log(r), t.orderList = [].concat(e(t.orderList), e(r.list)), r.list.length < 10 && (t.noMore = !0)
        })))
      },
      getUserInfo: function() {
        var e = this,
          t = n.index.getUserProfile;
        n.index.canIUse("getUserProfile") || (t = n.index.getUserInfo), t({
          success: function(t) {
            e.addUser(JSON.parse(t.rawData))
          },
          fail: function(e) {
            console.log(e), 21500 !== e.errNo && a.refuseAuth()
          }
        })
      },
      addUser: function(e) {
        var t = this,
          r = o.globalData,
          n = r.openid,
          s = r.appid,
          i = r.unionid,
          u = r.ver;
        this.$api.userInfo({
          data: {
            headImg: e.avatarUrl,
            nickName: e.nickName,
            openid: n,
            appid: s,
            unionid: i,
            ver: u
          }
        }).then((function(r) {
          t.userData = r.data, t.vip = r.data.vip, t.userInfo = e, a.setStorage("userInfo", e)
        })).catch((function(e) {
          console.log(e)
        }))
      },
      copyOrderId: function(e) {
        n.index.setClipboardData({
          data: e,
          success: function() {
            n.index.showToast({
              title: "复制成功"
            })
          }
        })
      }
    }
  };
Array || n.resolveComponent("navBack")();
var i = n._export_sfc(s, [
  ["render", function(e, t, r, a, o, s) {
    return n.e({
      a: !o.userInfo
    }, o.userInfo ? n.e({
      f: o.userInfo.avatarUrl,
      g: n.t(o.userInfo.nickName),
      h: o.userData.vip > 0
    }, o.userData.vip > 0 ? {
      i: n.t(o.userData.end_date)
    } : {}) : n.e({
      b: n.o((function() {
        return s.getUserInfo && s.getUserInfo.apply(s, arguments)
      })),
      c: n.o((function() {
        return s.getUserInfo && s.getUserInfo.apply(s, arguments)
      })),
      d: o.userData.vip > 0
    }, o.userData.vip > 0 ? {
      e: n.t(o.userData.end_date)
    } : {}), {
      j: o.orderList.length > 0
    }, o.orderList.length > 0 ? {
      k: n.f(o.orderList, (function(e, t, r) {
        return {
          a: n.t(e.out_order_no),
          b: n.o((function(t) {
            return s.copyOrderId(e.out_order_no)
          }), t),
          c: n.t(e.show_status),
          d: n.n("type" + e.status),
          e: e.icon,
          f: n.t(e.time),
          g: n.t(e.pay_time),
          h: n.t(e.money),
          i: t
        }
      }))
    } : {}, {
      l: n.o((function() {
        return s.getOrderList && s.getOrderList.apply(s, arguments)
      }))
    })
  }]
]);
wx.createPage(i);