var e = require("../../@babel/runtime/helpers/objectSpread2"),
  t = require("../../common/vendor.js"),
  n = {
    data: function() {
      return {
        host: "https://min-api.xliii.cn/",
        imageInfo: null,
        popText: ""
      }
    },
    onLoad: function(e) {
      if (!e.res_id) return t.index.redirectTo({
        url: "/pages/index/index"
      });
      this.useAppAdTT(!0), this.getGameData(e.res_id)
    },
    onShareAppMessage: function(e) {
      var t, n = this.imageInfo.class,
        i = (null == (t = [{
          class: 1,
          title: "壁纸"
        }, {
          class: 2,
          title: "头像"
        }, {
          class: 3,
          title: "表情包"
        }, {
          class: 4,
          title: "背景"
        }, {
          class: 5,
          title: "动态壁纸"
        }].find((function(e) {
          return e.class == n
        }))) ? void 0 : t.title) || "原图",
        o = "/pages/preview_unlimit/preview_unlimit?res_id=".concat(this.imageInfo.res_id);
      return {
        channel: e.channel,
        imageUrl: !1,
        title: "点击下载同款" + i,
        path: o,
        extra: {
          withVideoId: !0
        }
      }
    },
    methods: {
      request: function(n) {
        var i = getApp().globalData,
          o = i.appid,
          a = i.ver;
        return t.index.request({
          url: this.host + n.url,
          method: "POST",
          header: {
            "content-type": "application/x-www-form-urlencoded"
          },
          data: e({
            appid: o,
            ver: a
          }, n.data)
        })
      },
      getGameData: function(e) {
        var n = this;
        this.request({
          url: "miniapi/TtSearchImg/searchImg",
          data: {
            res_id: e
          }
        }).then((function(e) {
          var i;
          if (!(null == (i = null == e ? void 0 : e.data) ? void 0 : i.data)) return t.index.redirectTo({
            url: "/pages/index/index"
          });
          n.imageInfo = e.data.data, n.playVideo()
        }))
      },
      bindBack: function() {
        getCurrentPages().length > 1 ? t.index.navigateBack() : t.index.redirectTo({
          url: "/pages/index/index"
        })
      },
      userAuthorize: function() {
        var e = this;
        this.downloading = !1;
        var n = "scope.album";
        t.index.getSetting({
          success: function(t) {
            console.log(t), t.authSetting[n] || void 0 === t.authSetting[n] ? e.downloadImage() : !1 === t.authSetting[n] && e.openSetting()
          }
        }), t.index.hideLoading()
      },
      openSetting: function() {
        var e = this;
        t.index.showModal({
          title: "提示",
          content: "请授权后保存图片到本地相册",
          success: function(n) {
            n.confirm ? t.index.openSetting({
              success: function(t) {
                t.authSetting["scope.writePhotosAlbum"] ? e.downloadImage() : e.showModal("下载失败")
              },
              fail: function(t) {
                e.showModal("下载失败")
              }
            }) : e.showModal("下载失败")
          }
        })
      },
      downloadImage: function(e) {
        var n = this;
        t.index.downloadFile({
          url: this.imageInfo.img,
          success: function(e) {
            console.log(e), t.index.saveImageToPhotosAlbum({
              filePath: e.tempFilePath,
              success: function() {
                n.showModal("下载成功")
              },
              fail: function(e) {
                10200 == e.errNo ? n.openSetting() : n.showModal("下载失败")
              }
            })
          },
          fail: function(e) {
            console.log(e), n.showModal("下载失败")
          }
        })
      },
      playVideo: function() {
        var e = this;
        this.useAppAdTT().then((function(t) {
          e.again = 0, t ? e.adReport(1) : e.adReport(2)
        })).catch((function(t) {
          again++, e.adReport(t)
        }))
      },
      useAppAdTT: function(e) {
        var n = getApp().globalData.videoAd;
        return console.log(123), n || (n = t.index.createRewardedVideoAd({
          adUnitId: "9mzhykpa3vs8i2ds47"
        }), getApp().globalData.videoAd = n), new Promise((function(i, o) {
          n ? (e || n.load().then((function() {
            n.show()
          })).catch((function(e) {
            o(!1)
          })), n.onError((function(e) {
            console.log("err", e), o(e.errCode)
          })), n.onClose((function(e) {
            t.index.hideLoading(), e.isEnded ? i(!0) : i(!1)
          }))) : o(!1)
        }))
      },
      adReport: function(e) {
        var t = this;
        this.request({
          url: "miniapi/TtSearchImg/searchAdReport",
          data: {
            res_id: this.imageInfo.res_id,
            type: e,
            ad_err: 1 == e ? 0 : e
          }
        }).then((function() {
          1 == e ? t.downloadImage() : 2 != e ? 1003 == e || 1004 == e ? t.showModal("广告异常\n请在24小时后重试") : t.downloadImage() : t.showModal("广告之后才能完成下载~")
        }))
      },
      showModal: function(e) {
        var n = this;
        t.index.hideLoading(), this.popText = e, "下载成功" != e && setTimeout((function() {
          n.closeModal()
        }), 1e3)
      },
      closeModal: function() {
        this.popText = ""
      }
    }
  },
  i = t._export_sfc(n, [
    ["render", function(e, n, i, o, a, d) {
      return t.e({
        a: a.imageInfo
      }, a.imageInfo ? t.e({
        b: 1 == a.imageInfo.class
      }, 1 == a.imageInfo.class ? {
        c: a.imageInfo.img
      } : {
        d: a.imageInfo.img
      }) : {}, {
        e: t.o((function() {
          return d.playVideo && d.playVideo.apply(d, arguments)
        })),
        f: t.o((function() {
          return d.bindBack && d.bindBack.apply(d, arguments)
        })),
        g: a.popText
      }, a.popText ? t.e({
        h: "下载成功" == a.popText
      }, "下载成功" == a.popText ? {
        i: t.o((function(e) {
          return a.popText = ""
        }))
      } : a.popText ? {
        k: t.t(a.popText),
        l: a.popText.length > 11 ? 1 : ""
      } : {}, {
        j: a.popText
      }) : {})
    }],
    ["__scopeId", "data-v-35bb2830"]
  ]);
n.__runtimeHooks = 2, wx.createPage(i);