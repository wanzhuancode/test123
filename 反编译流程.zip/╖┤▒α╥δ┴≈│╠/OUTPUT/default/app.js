require("./@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, Symbol.toStringTag, {
  value: "Module"
});
var M = require("./common/vendor.js"),
  a = require("./service/api.js"),
  s = require("./utils/js/common.js");
Math;
var t = {
    globalData: {
      ver: "7.0.0",
      appid: "wx41cd4f32cf8164b3",
      host: "https://min-api.xliii.cn/",
      vote_key: "WAG0JIUGYALACVJF",
      openid: "",
      unionid: "",
      check: 0,
      config: {},
      img_config: {},
      accData: {},
      imageList: [],
      videoAd: null,
      activity: 0,
      userData: null,
      suid: "",
      res_id: 0,
      acc_id: 0,
      alb_id: 0,
      code: 0,
      min_push: 0,
      inputFocus: !0,
      updatedApp: function() {
        console.log("update");
        var a = M.index.getUpdateManager();
        a.onCheckForUpdate((function(M) {
          console.log(M.hasUpdate)
        })), a.onUpdateReady((function() {
          M.index.showModal({
            title: "更新提示",
            content: "新版本已经准备好，是否重启应用？",
            success: function(M) {
              M.confirm && a.applyUpdate()
            }
          })
        })), a.onUpdateFailed((function() {}))
      }
    },
    onLaunch: function(M) {
      console.log("App Launch"), this.globalData.updatedApp()
    },
    onShow: function(M) {
      this.globalData.acc_id = M.query.acc_id || 0, this.globalData.alb_id = M.query.alb_id || 0, this.globalData.res_id = M.query.res_id || 0, this.globalData.min_push = M.query.min_push || 0, console.log("App Show")
    },
    onHide: function() {
      console.log("App Hide")
    }
  },
  p = function() {
    return "./components/complain.js"
  },
  y = ["喧闹的城丶空白的心", "壹直在改變，", "北凤男飞", "凉堇年*", "她是校花我是笑话", "一念之间°", "化思念为星。", "尽北", "微笑背后谁能懂我", "孤獨病°", "明知你是梦″却不愿醒来", "放下る", "私定终生ら", "為你鐘情", "孤痞°", "流年渲染成殇つ", "以心换心", "西瓜不懂柠檬的酸√", "心╰→比柠檬酸", "梦想三旬", "初璃兮微°", "梦毁心亡√", "青石巷里的旧少年i", "生人勿扰", "執筆·抒情殇", "沵媞莪旳獨家記憶", "九卿臣", "无处安放的小情绪i", "狂炎☆龙灬", "时空猎人", "艳司令", "仿魜dē风筝", "珵", "怪我过分执着", "让眼泪放纵", "旧梦为谁逗留", "呛了眼睛熬了心", "仅此，而已", "絕版無敵男丶", "主動久了也會累嘚", "是否不一样爱", "谁念西风独自凉", "有些人，一转身就是一生", "招摇过市小b", "╰妳终究不属于珴╮", "念來過倒會都逼二", "情何以堪Reds°", "屌絲逆襲了。", "搁浅的旧时光ζ", "心中有个小执念"],
  j = ["https://p2.a.yximgs.com/uhead/AB/2021/07/08/14/BMjAyMTA3MDgxNDM2NDZfMjQxOTgwNzEwMF8yX2hkOTk4XzkwNw==_s.jpg", "https://p5.a.yximgs.com/uhead/AB/2021/05/28/10/BMjAyMTA1MjgxMDIwNDZfMTQzMDI4Mjk4NF8yX2hkNjM1XzkzMg==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/08/27/16/BMjAyMTA4MjcxNjQwMTdfMjMzNDY0MzU1OF8yX2hkMjIxXzI2MA==_s.jpg", "https://p5.a.yximgs.com/uhead/AB/2021/10/18/10/BMjAyMTEwMTgxMDAxMDZfMjU5NDMwMzYxMF8xX2hkMTk3XzIxMA==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/11/23/14/BMjAyMTExMjMxNDUzMDFfMTE1MTM0MTI4XzJfaGQxMjNfNzEw_s.jpg", "https://p5.a.yximgs.com/uhead/AB/2021/05/11/14/BMjAyMTA1MTExNDEwMTVfMjE0ODIwMzgwNV8yX2hkODMzXzU5OA==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2019/08/30/14/BMjAxOTA4MzAxNDI2NTRfMTExNjA3MTA3Nl8xX2hkOTM0XzY0Mw==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/03/23/11/BMjAyMTAzMjMxMTI2NTBfMjI4Nzc3OTMzM18xX2hkMjk1XzI1Nw==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/12/10/19/BMjAyMTEyMTAxOTEzMDdfMjQ0NDcyODgzNF8xX2hkODIzXzY5Ng==_s.jpg", "https://p3.a.yximgs.com/uhead/AB/2021/02/22/15/BMjAyMTAyMjIxNTMzMjVfMTEzMTkzOTc1MF8yX2hkMTY5Xzc3Mw==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2020/09/04/17/BMjAyMDA5MDQxNzU1NTFfMTUyODU1Nzk0MV8yX2hkMTZfNTIy_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/12/07/17/BMjAyMTEyMDcxNzU2MjJfMjA1Nzc1ODE2XzFfaGQ0NjhfNzM4_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/07/26/20/BMjAyMTA3MjYyMDU0NDlfODk0ODIyMzU0XzJfaGQ1NzlfNTc3_s.jpg", "https://p2.a.yximgs.com/uhead/AB/2021/12/10/21/BMjAyMTEyMTAyMTUyMzJfODIxMTYyMjQ2XzFfaGQ2OThfNjY1_s.jpg", "https://p3.a.yximgs.com/uhead/AB/2022/01/02/17/BMjAyMjAxMDIxNzAyMThfMjE0NTg1OTE5MF8yX2hkODIxXzUyMw==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/11/14/13/BMjAyMTExMTQxMzMyNTBfMjM0MzY5MTIyMl8yX2hkMTM5Xzc3Mw==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/10/29/09/BMjAyMTEwMjkwOTU3NTZfNzc1NzkzOF8yX2hkMjM0XzcxOA==_s.jpg", "https://p2.a.yximgs.com/uhead/AB/2020/09/28/15/BMjAyMDA5MjgxNTE2NTBfMTUzMTEzMzI2OV8yX2hkMzI4XzkwOQ==_s.jpg", "https://p5.a.yximgs.com/uhead/AB/2021/08/17/11/BMjAyMTA4MTcxMTUzMzRfMjEyMjI2NzY3Nl8yX2hkNDI3XzY5_s.jpg", "https://p2.a.yximgs.com/uhead/AB/2021/07/12/13/BMjAyMTA3MTIxMzUxNDBfMTIwMTY3ODY1XzJfaGQyNDhfODE4_s.jpg", "https://p3.a.yximgs.com/uhead/AB/2021/04/13/14/BMjAyMTA0MTMxNDA2MjZfMTU4NjYwMzA2NV8yX2hkODM5Xzc2NQ==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/05/22/15/BMjAyMTA1MjIxNTEwMjFfMjI4MzU5NDk1N18yX2hkMzU4XzczMQ==_s.jpg", "https://p3.a.yximgs.com/uhead/AB/2021/10/29/13/BMjAyMTEwMjkxMzI4NDNfMjAzODQ2NDkzOF8xX2hkNDQ1XzUxMA==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/02/08/20/BMjAyMTAyMDgyMDA0MDRfMjg1NDQ1NTEyXzFfaGQ3NDVfODU=_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/11/04/12/BMjAyMTExMDQxMjA2MzBfNzMxMTc4NDY1XzFfaGQ0NjVfNTM3_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/10/05/00/BMjAyMTEwMDUwMDM2MTlfMTM2MTE3NjM4N18yX2hkNjg2XzQxNg==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/08/08/19/BMjAyMTA4MDgxOTM0MDhfMjQ1NTYzMjA1Ml8yX2hkNDk1XzU5Ng==_s.jpg", "https://p2.a.yximgs.com/uhead/AB/2021/11/30/18/BMjAyMTExMzAxODUyMzlfMjI2ODA4NTM1M18yX2hkMjEyXzU4OA==_s.jpg", "https://p2.a.yximgs.com/uhead/AB/2021/11/11/16/BMjAyMTExMTExNjI3MThfMTc5NTI5MzE3NF8yX2hkNDhfMTky_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/08/18/17/BMjAyMTA4MTgxNzE2NTFfMjIzNjk2MTM4MV8yX2hkMTU5Xzc1NA==_s.jpg", "https://p2.a.yximgs.com/uhead/AB/2021/12/09/12/BMjAyMTEyMDkxMjQzMjdfMjE1OTMwNTQyMF8yX2hkNTg2XzU4OA==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/12/17/18/BMjAyMTEyMTcxODM1MDBfMTY5MTM5MTYwN18yX2hkMTYzXzc2Ng==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2022/01/09/04/BMjAyMjAxMDkwNDM5NTlfMTU3MTIyNzc3MF8yX2hkOTAzXzIxMA==_s.jpg", "https://p4.a.yximgs.com/uhead/AB/2021/08/28/13/BMjAyMTA4MjgxMzE2NDdfMjE1OTM3MjcyMV8yX2hkNzUzXzI2OA==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/06/16/14/BMjAyMTA2MTYxNDA3NTBfMjAyODM1NjI0N18yX2hkMzM1XzkxOA==_s.jpg", "https://p4.a.yximgs.com/uhead/AB/2022/01/09/00/BMjAyMjAxMDkwMDEzMzRfMjA3OTU1NDgyN18yX2hkMjA0XzY0NA==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/11/30/21/BMjAyMTExMzAyMTA3NDVfNDQyMjYwOTY2XzJfaGQxODVfMzk4_s.jpg", "https://p3.a.yximgs.com/uhead/AB/2021/10/10/01/BMjAyMTEwMTAwMTA4NTZfMTkwMzc3NDcwN18xX2hkODQwXzQ3_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/12/31/18/BMjAyMTEyMzExODUzMzJfMTY5ODEyMTE1M18yX2hkMzY2Xzg2MA==_s.jpg", "https://p2.a.yximgs.com/uhead/AB/2021/07/24/16/BMjAyMTA3MjQxNjE0NTdfNTkyMTc3NDc0XzJfaGQ5MDJfMTMx_s.jpg", "https://p2.a.yximgs.com/uhead/AB/2021/01/01/22/BMjAyMTAxMDEyMjU5MzJfNjQyMjUzMjU0XzJfaGQzNTNfMzEx_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/11/11/11/BMjAyMTExMTExMTUyMzZfMjYxNDU5ODQzOF8yX2hkNzQwXzkxNA==_s.jpg", "https://p3.a.yximgs.com/uhead/AB/2021/12/19/15/BMjAyMTEyMTkxNTIxNTBfMjU3MDIyNTk5NF8yX2hkNzE4XzQzNw==_s.jpg", "https://p1.a.yximgs.com/uhead/AB/2021/03/12/19/BMjAyMTAzMTIxOTAyNDBfMTQ4ODcwODk2MF8yX2hkODczXzg0Ng==_s.jpg"];

function A() {
  var A = M.createSSRApp(t);
  return A.config.globalProperties.$api = a.api, A.config.globalProperties.$img_config = s.img_config, A.config.globalProperties.userCommonList = j, A.config.globalProperties.nameCommonList = y, A.config.globalProperties.$link = function(M) {
    var a = M.includes(".mp4") ? s.img_config.video_thumb : s.img_config.img_thumb;
    return s.img_config.domain + M + a
  }, A.component("complain", p), {
    app: A
  }
}
var o = M.wx$1.createInterstitialAd({
  adUnitId: "adunit-63223a32d8b8c88d"
});
setTimeout((function() {
  ! function a() {
    o.load().then((function() {
      o.show(), setTimeout((function() {
        console.log("ad-again-more"), o = M.wx$1.createInterstitialAd({
          adUnitId: "adunit-8a97a2922b2e30fb"
        }), a()
      }), 62e3)
    })).then((function() {
      setTimeout((function() {
        console.log("ad-again-del"), o.destroy()
      }), 3e4)
    })).catch((function(M) {
      console.log(M)
    }))
  }()
}), 32e3), A().app.mount("#app"), exports.createApp = A;